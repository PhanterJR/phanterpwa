import os
import glob
import importlib
import configparser
import shutil
import sass
import subprocess
import psutil
import time
from livereload import Server
from phanterpwa.builds import BuildViews
current_folder = os.path.dirname(__file__)

config = configparser.ConfigParser()
config.read(os.path.join(current_folder, 'config.ini'))
config['PATH']['project'] = current_folder
config['PATH']['api'] = os.path.join(current_folder, "api")
config['PATH']['app'] = path_app = os.path.join(current_folder, "app")
transcrypt_main_file = config['TRANSCRYPT']['main_file']
project_version = config['PROJECT']['version']
path_www = os.path.join(path_app, "www")
python_env = config['ENVIRONMENT']['python']
if not os.path.exists(python_env):
    raise "The python configured in 'config.ini' for your environment was not found in %s" % python_env

with open(os.path.join(current_folder, 'config.ini'), 'w') as configfile:
    config.write(configfile)

if os.path.exists("pid"):
    with open("pid", "r") as f:
        pid = f.read().strip()
        if pid:
            for p in psutil.process_iter():
                if int(p.pid) == int(pid):
                    cmd_line = p.cmdline()
                    if "python" in os.path.basename(cmd_line[0]) and "run.py" == os.path.basename(cmd_line[-1]):
                        p.terminate()
                        print("close server. PID: ", pid)
                        break
            for c in range(3):
                print('wait: pass %s second(s)' % (c + 1))
                time.sleep(1)
        else:
            print("Previous server not found")


if not os.path.exists(os.path.join(path_app, "sources", "scripts", transcrypt_main_file)):
    with open(os.path.join(path_app, "sources", "scripts", transcrypt_main_file), "w") as f:
        f.write("print(\"Hello World!\")\n")

transcrypt_main_file_path = os.path.join(path_app, "sources", "scripts", transcrypt_main_file)

try:
    shutil.rmtree(path_www)
except Exception as e:
    print('Error while deleting directory: %s' % e)

css_by_path = []


def renew_statics():
    if os.path.exists(os.path.join(path_www, "static")):
        try:
            shutil.rmtree(os.path.join(path_www, "static"))
        except Exception as e:
            print('Error while deleting directory: %s' % e)
    shutil.copytree(
        os.path.join(path_app, "sources", "statics"),
        os.path.join(path_www, "static", str(project_version))
    )


renew_statics()


def compile_styles():
    list_sass = glob.glob(os.path.join(path_app, "sources", "styles", "*"))
    exclude = ["__pycache__", "__init__.py"]
    for s in list_sass:
        os.makedirs(
            os.path.join(
                path_www, "static", str(project_version), "css"), exist_ok=True)
        if os.path.isfile(s) and s[-5:] == ".sass":
            print("compiling Sass to Css: %s" % s)
            with open(s, "r") as f:
                filename = os.path.basename(s)[0:-5]
                c = ""
                temp_c = f.readlines()
                for t in temp_c:
                    if t[0:12] == "$app-version":
                        t = "$app-version: %s\n" % project_version
                    c = "".join([c, t])
                compressed = sass.compile(string=c, indented=True, output_style="compressed")
                humanized = sass.compile(string=c, indented=True, output_style="expanded") + "\n"
                with open(
                    os.path.join(
                        path_app, "sources", "statics", "%s.css" % filename), "w") as o:
                    o.write(humanized)
                with open(
                    os.path.join(
                        path_www, "static", str(project_version), "css", "%s.min.css" % filename), "w") as o:
                    o.write(compressed)
        elif os.path.isdir(s) and s not in exclude:
            css_by_path.append(s)
            n_list_sass = glob.glob(os.path.join(s, "*.sass"))
            filename = os.path.split(s)[-1]
            pre_c = ""
            for n in n_list_sass:
                with open(n, "r") as f:
                    c = ""
                    temp_c = f.readlines()
                    for t in temp_c:
                        if t[0:12] == "$app-version":
                            t = "$app-version: %s\n" % project_version
                        c = "".join([c, t])
                    pre_c = "".join([pre_c, c, "\n"])
            joined_compressed = sass.compile(string=pre_c, indented=True, output_style="compressed")
            joined_humanized = sass.compile(string=pre_c, indented=True, output_style="expanded")
            with open(
                os.path.join(s, "%s.css" % filename), "w") as o:
                o.write(joined_humanized)
            with open(
                os.path.join(
                    path_www, "static", str(project_version), "css", "%s.min.css" % filename), "w") as o:
                o.write(joined_compressed)


compile_styles()


def compile_html(file, base="", ignore=["__init__.py"]):
    if os.path.isfile(file) and os.path.basename(file) not in ignore and file[-3:] == ".py":
        print("compiling Python to html: %s" % file)
        i_mod = "%s" % (os.path.basename(file)[0:-3])
        if base:
            i_mod = "%s.%s" % (base, i_mod)
        i = importlib.import_module(i_mod)
        importlib.reload(i)
        name = "".join([*i_mod.split(".")[-1], ".html"])
        files_www = os.path.join(path_www, *i_mod.split(".")[3:-1])
        builder = BuildViews(name, i.html, files_www)
        builder.build()


def compile_htmls(source, base=""):
    # htmls to www
    list_all = glob.glob(os.path.join(source, "*"))
    for x in list_all:
        if os.path.isdir(x) and not os.path.basename(x) == "__pycache__":
            if base:
                new_base = "%s.%s" % (base, os.path.basename(x))
                compile_htmls(x, new_base)
        elif os.path.isfile(x):
            compile_html(x, base=base)


compile_htmls(os.path.join(path_app, "sources", "htmls"), "app.sources.htmls")


def compile_script(file, python_env, ignore=["__init__.py"]):
    print("compiling Python to Javascript: %s" % file)
    if os.path.basename(file) not in ignore:
        subprocess.run("%s -m transcrypt %s -e5 -m" %
                    (python_env, file))
        if not os.path.exists(os.path.join(path_www, "static", str(project_version), "js", "transcrypt")):
            os.makedirs(os.path.join(path_www, "static", str(project_version), "js", "transcrypt"), exist_ok=True)
        list_all = glob.glob(os.path.join(path_app, "sources", "scripts", "__target__", "*"))
        for x in list_all:
            if os.path.isfile(x) and not x[-3:] == ".py":
                shutil.copy(
                    x,
                    os.path.join(path_www, "static", str(project_version), "js", "transcrypt", os.path.basename(x))
                )
        subprocess.run("%s -m transcrypt %s -n -e5 -dm" %
                    (python_env, file))


compile_script(transcrypt_main_file_path, python_env)


server = Server()

server.watcher.ignored_dirs = ["*.css", "*.py"]
server.watch(
    os.path.join(path_app, "sources", "styles", "*.sass"),
    lambda: compile_styles())
for x in css_by_path:
    server.watch(
        os.path.join(x, "*.sass"),
        lambda: compile_styles())

server.watcher.ignored_dirs = ["__init__.py", "__pycache__"]
server.watch(os.path.join(
    path_app, "sources", "htmls"), lambda: compile_htmls(
        os.path.join(path_app, "sources", "htmls"), "app.sources.htmls"))

server.watcher.ignored_dirs = ["__init__.py", "__target__"]
server.watch(
    os.path.join(path_app, "sources", "scripts"),
    lambda: compile_script(transcrypt_main_file_path, python_env)
)
server.watch(
    os.path.join(path_app, "sources", "statics"),
    renew_statics
)
with open("art", "r") as f:
    print("\n\n", f.read(), "\n\n\n")

print("Server running...")
print('PID process: %s' % os.getpid())
with open('pid', 'w') as f:
    f.write(str(os.getpid()))

server.serve(root=path_www)
