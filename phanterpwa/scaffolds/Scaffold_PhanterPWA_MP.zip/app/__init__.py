import os
import configparser

config_folder = os.path.join(os.path.dirname(__file__), "..")
print('------------------->',config_folder)
config = configparser.ConfigParser()
config.read(os.path.join(config_folder, 'config.ini'))

__author__ = config['PROJECT']['author']
__version__ = config['PROJECT']['version']
__project__ = config['PROJECT']['name']
__path_project__ = config['PATH']['project']
__path_app__ = config['PATH']['app']
__path_api__ = config['PATH']['api']
