import phanterpwa
import routes
from org.transcrypt.stubs.browser import __pragma__
__pragma__("alias", "JQuery", "$")
__pragma__("skip")
JQuery = 0
__pragma__("noskip")

DIV = phanterpwa.XmlConstructor.tagger('div')
BR = phanterpwa.XmlConstructor.tagger('br', singleton=True)
CONCATENATE = phanterpwa.CONCATENATE

routes.routes.main_page()
