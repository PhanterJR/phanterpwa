import cmp_user_login
import left_bar
from org.transcrypt.stubs.browser import __pragma__

__pragma__('alias', "JQuery", "$")
__pragma__('skip')
JQuery = 0
__pragma__('noskip')


def main_page():
    # cmp_user_login.start()
    left_bar.start()
    JQuery("#main-container").load("./pages/main.html")
