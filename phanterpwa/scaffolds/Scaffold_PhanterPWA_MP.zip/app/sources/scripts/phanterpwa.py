from routes import routes
# pragmas

from org.transcrypt.stubs.browser import __pragma__
__pragma__('alias', "JQuery", "$")
__pragma__('skip')

# it is ignored on transcrypt
window = JQuery = document = 0

__pragma__('noskip')

__pragma__('kwargs')


class XmlConstructor():

    def __init__(self, tag, singleton, *content, **attributes):
        self.tag = tag
        self.singleton = singleton
        self.content = content
        self.attributes = attributes

    @property
    def tag(self):
        return self._tag

    @tag.setter
    def tag(self, tag):
        self._tag = tag

    @property
    def singleton(self):
        return self._singleton

    @singleton.setter
    def singleton(self, singleton):
        if isinstance(singleton, bool):
            self._singleton = singleton
        else:
            raise TypeError("The singleton must be bool, given: {0}".format(str(singleton)))

    def xml(self):
        if (self.singleton is True):
            self.el = JQuery("<{0}>".format(self.tag))
        else:
            self.el = JQuery("<{0}></{0}>".format(str(self.tag)))
            for c in self.content:
                if isinstance(c, str):
                    self.el.append(JQuery("<div/>").text(c).html())
                elif isinstance(c, XmlConstructor):
                    self.el.append(c.jquery())
                else:
                    self.el.append(c)
        for t in self.attributes.keys():
            if t.startswith("_"):
                self.el.attr(t[1:], self.attributes[t])

        return self.el[0].outerHTML

    def __str__(self):
        return self.xml()

    def jquery(self):
        self.xml()
        return self.el

    @staticmethod
    def tagger(tag, singleton=False):
        return lambda *content, **attributes: XmlConstructor(tag, singleton, *content, **attributes)


class XML(XmlConstructor):
    def __init__(self, *content):
        XmlConstructor.__init__(self, '', False, *content)

    def xml(self):
        html = ""
        for c in self.content:
            if isinstance(c, str):
                html += c
            elif isinstance(c, XmlConstructor):
                html += c.xml()
            else:
                html += c
        return html

    def jquery(self):
        html = self.xml()
        return html


class CONCATENATE(XmlConstructor):
    def __init__(self, *content):
        XmlConstructor.__init__(self, '', False, *content)

    def xml(self):
        html = ""
        for c in self.content:
            if isinstance(c, str):
                html += JQuery("<div/>").text(c).html()
            elif isinstance(c, XmlConstructor):
                html += c.xml()
            else:
                html += c
        return html

    def jquery(self):
        html = self.xml()
        return html


__pragma__('nokwargs')


def main_container_height():

    al = JQuery(window).height() - 134
    w = JQuery(window).width()
    if w <= 600:
        JQuery("#left_bar").css("top", 56)
    else:
        JQuery("#left_bar").css("top", 64)
    al = JQuery(window).height() - 134

    JQuery("#main-container").css('height', al)


def ready():
    print("ready")
    print(routes)


main_container_height()
JQuery(window).on('resize', main_container_height)

JQuery(document).ajaxComplete(lambda:
        print("ajaxComplete")
)
JQuery(document).ready(ready)
