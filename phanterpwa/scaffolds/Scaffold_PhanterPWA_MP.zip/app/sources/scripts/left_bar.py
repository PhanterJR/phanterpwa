from org.transcrypt.stubs.browser import __pragma__
__pragma__('alias', "JQuery", "$")
__pragma__('skip')
JQuery = 0
__pragma__('noskip')


def open_close_menu():
    opened = JQuery("#left_bar").hasClass("enabled")
    if opened:
        JQuery("#left_bar").removeClass("enabled")
        JQuery("#menu-button-main-page").removeClass("enabled")
    else:
        JQuery("#left_bar").addClass("enabled")
        JQuery("#menu-button-main-page").addClass("enabled")


def start():
    JQuery(
        "#menu-button-main-page"
    ).off(
        "click.button_menu_left"
    ).on(
        "click.button_menu_left",
        open_close_menu
    )
