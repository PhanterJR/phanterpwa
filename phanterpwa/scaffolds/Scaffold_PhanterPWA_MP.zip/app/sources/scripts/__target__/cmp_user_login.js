// Transcrypt'ed from Python, 2019-05-29 00:28:12
import {AssertionError, AttributeError, BaseException, DeprecationWarning, Exception, IndexError, IterableError, KeyError, NotImplementedError, RuntimeWarning, StopIteration, UserWarning, ValueError, Warning, __JsIterator__, __PyIterator__, __Terminal__, __add__, __and__, __call__, __class__, __envir__, __eq__, __floordiv__, __ge__, __get__, __getcm__, __getitem__, __getslice__, __getsm__, __gt__, __i__, __iadd__, __iand__, __idiv__, __ijsmod__, __ilshift__, __imatmul__, __imod__, __imul__, __in__, __init__, __ior__, __ipow__, __irshift__, __isub__, __ixor__, __jsUsePyNext__, __jsmod__, __k__, __kwargtrans__, __le__, __lshift__, __lt__, __matmul__, __mergefields__, __mergekwargtrans__, __mod__, __mul__, __ne__, __neg__, __nest__, __or__, __pow__, __pragma__, __proxy__, __pyUseJsNext__, __rshift__, __setitem__, __setproperty__, __setslice__, __sort__, __specialattrib__, __sub__, __super__, __t__, __terminal__, __truediv__, __withblock__, __xor__, abs, all, any, assert, bool, bytearray, bytes, callable, chr, copy, deepcopy, delattr, dict, dir, divmod, enumerate, filter, float, getattr, hasattr, input, int, isinstance, issubclass, len, list, map, max, min, object, ord, pow, print, property, py_TypeError, py_iter, py_metatype, py_next, py_reversed, py_typeof, range, repr, round, set, setattr, sorted, str, sum, tuple, zip} from './org.transcrypt.__runtime__.js';
var __name__ = 'cmp_user_login';
export var switch_menu_login = function () {
	if ($ ('.cmp-bar_user_and_menu-container').hasClass ('enabled')) {
		$ ('.cmp-bar_user_and_menu-container').removeClass ('enabled');
	}
	else {
		$ ('.cmp-bar_user_and_menu-container').addClass ('enabled');
	}
};
export var bind_click = function () {
	$ ('#toggle-cmp-bar_user').off ('click.cmp_user_login').on ('click.cmp_user_login', switch_menu_login);
};
export var start = function () {
	$ ('#user_login_and_menu-container').load ('./extends/component_user_nologin.html', bind_click);
};

//# sourceMappingURL=cmp_user_login.map