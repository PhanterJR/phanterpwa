from org.transcrypt.stubs.browser import __pragma__
from main_page import main_page
__pragma__('jsiter')
routes = {
    'main_page': main_page
}
__pragma__('nojsiter')
