from org.transcrypt.stubs.browser import __pragma__
__pragma__('alias', "JQuery", "$")
__pragma__('skip')
JQuery = 0
__pragma__('noskip')


def switch_menu_login():
    if JQuery(".cmp-bar_user_and_menu-container").hasClass("enabled"):
        JQuery(".cmp-bar_user_and_menu-container").removeClass("enabled")
    else:
        JQuery(".cmp-bar_user_and_menu-container").addClass("enabled")


def bind_click():
    JQuery(
        "#toggle-cmp-bar_user"
    ).off(
        "click.cmp_user_login"
    ).on(
        "click.cmp_user_login", switch_menu_login
    )


def start():
    JQuery("#user_login_and_menu-container").load("./extends/component_user_nologin.html", bind_click)
