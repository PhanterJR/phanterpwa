# -*- coding: utf-8 -*-

from phanterpwa.helpers import (
    DIV,
    SCRIPTMINIFY,
    CONCATENATE,
    H3,
)

from app.sources.htmls.components.preloader_circle_big import html as LENDO

html = CONCATENATE(
    H3(DIV("Auth Users", _class="phanterpwa-container"), _class="titulo_maincontainer"),
    DIV(
        DIV(
            DIV(
                DIV(
                    DIV(DIV(LENDO, _class="espera_container"), _id="lista_auth_user", _class="simple-border"),
                    _class="phanterpwa-card-container phanterpwapages-card_buttons-container"),
                _class="card"
            ),
            _class="new-container"
        ),
        _class="phanterpwa-container"
    ),
    SCRIPTMINIFY("phanterpwapages.admin_auth_user();"),
)
