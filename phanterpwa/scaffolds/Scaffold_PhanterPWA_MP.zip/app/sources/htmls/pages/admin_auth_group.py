# -*- coding: utf-8 -*-

from phanterpwa.helpers import (
    DIV,
    SCRIPTMINIFY,
    CONCATENATE,
    H3,
)


html = CONCATENATE(
    H3(DIV("Auth Groups", _class="phanterpwa-container"), _class="titulo_maincontainer"),
    DIV(
        DIV(
            DIV(
                DIV(
                    DIV(_id="lista_auth_group", _class="simple-border"),
                    _class="phanterpwa-card-container phanterpwapages-card_buttons-container"),
                _class="card"
            ),
            _class="new-container"
        ),
        _class="phanterpwa-container"
    ),
    SCRIPTMINIFY("phanterpwapages.admin_groups();"),
)
