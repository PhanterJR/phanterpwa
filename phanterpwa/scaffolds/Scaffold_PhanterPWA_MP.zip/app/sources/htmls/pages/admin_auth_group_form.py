# -*- coding: utf-8 -*-

from phanterpwa.helpers import (
    DIV,
    H3,
    FORM,
    CONCATENATE,
    SCRIPTMINIFY
)

from phanterpwa.components.materialize import (
    MaterializeInputText,
    MaterializeInputHidden,
    MaterializeButtonForm
)

html = CONCATENATE(
    H3(DIV("Auth Group", _class="phanterpwa-container"), _class="titulo_maincontainer"),
    DIV(
        DIV(
            DIV(
                DIV(
                    FORM(
                        MaterializeInputHidden(
                            "csrf_token",
                            "csrf token",
                            default="",
                            error="",
                            _phanterpwaformvalidator_isnotempty="",
                            _phanterpwaformvalidator_group="auth_group",
                        ),
                        DIV(
                            MaterializeInputText(
                                "role",
                                "Papel",
                                default="",
                                error="",
                                _phanterpwaformvalidator_isnotempty="",
                                _phanterpwaformvalidator_group="auth_group",
                                _class="col s12 m6"
                            ),
                            MaterializeInputText(
                                "description",
                                "Descrição",
                                default="",
                                error="",
                                _phanterpwaformvalidator_group="auth_group",
                                _class="col s12 m6"
                            ),
                            _class="row reset-css-row"
                        ),
                        DIV(
                            DIV(
                                DIV(
                                    DIV(_class="phantergallery_progressbar-movement"),
                                    _class="phantergallery_progressbar"),
                                _class="progressbar-form-modal"),
                            _class="progressbar-container-form-modal"),
                        DIV(
                            DIV(
                                MaterializeButtonForm(
                                    "auth_group-ajax-button-save",
                                    "Salvar Mudanças",
                                    _class="waves-effect waves-teal",
                                    _phanterpwaformvalidator_submit="",
                                    _phanterpwaformvalidator_group="auth_group"
                                ),
                                _class='buttons-form-container'
                            ),
                            _class="input-field col s12"
                        ),
                        _action="#",
                        _id="form-auth_group",
                        _class="form-auth_group row",
                        _enctype="multipart/form-data",
                        _method="post",
                        _phanterpwaformvalidator_group="auth_group",
                        _autocomplete="off"
                    ),
                    _class='auth_group-container phanterpwa-card-container'
                ),
                _class="card"
            ),
            _class="new-container"
        ),
    _class="phanterpwa-container"),
    SCRIPTMINIFY(
        "phanterpwapages.admin_auth_group_form();",
        _type="text/javascript"
    ),
)
