# -*- coding: utf-8 -*-

from phanterpwa.helpers import (
    CONCATENATE,
    DIV,
    SCRIPTMINIFY,
    FORM,
    H3,
    SPAN,
    STRONG,
    H6,
    IMG,
    P
)

from phanterpwa.components.phantergallery import (
    PhanterGalleryInput)

from phanterpwa.components.materialize import (
    MaterializeInputText,
    MaterializeInputHidden,
    MaterializeButtonForm,
    MaterializeSearchBar,
    MaterializeFloatButton,
    MaterializeTabs,
    MaterializeInputTextMultiline
)
from app.sources.htmls.components.preloader_circle_big import html as LENDO

search_bar = MaterializeSearchBar("search_produto")
search_bar.addOptionInSelect("codigo", "Código", _selected="selected")
search_bar.addOptionInSelect("produto", "Produto")
search_bar.addOptionInSelect("descricao", "Descrição")

search_bar_fornecedor = MaterializeSearchBar("search_fornecedor")

search_bar_fornecedor.addOptionInSelect(
    "cnpj",
    "CNPJ",
    _selected="selected"
)

search_bar_fornecedor.addOptionInSelect(
    "razao_social",
    "Razão Social"
)

search_bar_fornecedor.addOptionInSelect(
    "fantasia",
    "Fantasia"
)

float_produto = MaterializeFloatButton(
    "add",
    _id="adicionar_produto_modal"
)

float_fornecedor = MaterializeFloatButton(
    "add",
    _id="adicionar_fornecedor_modal"
)


tab1 = CONCATENATE(
    P(
        "ESCOLHA O FORNECEDOR DO PRODUTO",
        _class="flow-text flow-titulo titulo-tabs-estoque"
    ),
    search_bar_fornecedor,
    DIV(
        DIV(
            LENDO,
            _id="espera_container",
            _class="espera_container link_href link",
            _link_href="estoque_adicionar_produto_no_estoque"),
        _id="lista_fornecedores"),
    float_fornecedor,
)

tab2 = CONCATENATE(
    P("ESCOLHA O PRODUTO QUE IRÁ ADICIONAR", _class="flow-text flow-titulo titulo-tabs-estoque"),
    search_bar,
    DIV(
        DIV(
            LENDO,
            _id="espera_container",
            _class="espera_container link_href link",
            _link_href="estoque_adicionar_produto_no_estoque"),
        _id="lista_produtos"),
    float_produto,
)
materialize_total = MaterializeInputText(
    "preco_total",
    "Preço Total (R$)",
    id_input="form-entrada-input-preco_total",
    default="R$ 0,00",
    error="",
    _class="col s12 m5 l6",
    _phanterpwaformvalidator_valueisdifferentof="R$ 0,00",
    _phanterpwaformvalidator_group="entrada",
)
materialize_total.disable()
tab3 = CONCATENATE(
    P("ENTRADA DO PRODUTO", _class="flow-text flow-titulo titulo-tabs-estoque"),
    DIV(
        DIV(
            DIV(
                DIV(
                    DIV(
                        FORM(
                            MaterializeInputHidden(
                                "csrf_token",
                                "csrf token",
                                id_input="form-entrada-input-csrf_token",
                                default="",
                                error="",
                                _phanterpwaformvalidator_isnotempty="",
                                _phanterpwaformvalidator_group="entrada",
                            ),
                            MaterializeInputHidden(
                                "id_produto",
                                "id_produto",
                                id_input="form-entrada-input-id_produto",
                                default="",
                                error="",
                                _phanterpwaformvalidator_isnotempty="",
                                _phanterpwaformvalidator_group="entrada",
                            ),
                            MaterializeInputHidden(
                                "id_fornecedor",
                                "id_fornecedor",
                                id_input="form-entrada-input-id_fornecedor",
                                default="",
                                error="",
                                _phanterpwaformvalidator_isnotempty="",
                                _phanterpwaformvalidator_group="entrada",
                            ),
                            MaterializeInputText(
                                "marca",
                                "Marca",
                                id_input="form-entrada-input-marca",
                                default="",
                                error="",
                                _class="col s12 m12 l12",
                                _phanterpwaformvalidator_group="entrada",
                            ),
                            MaterializeInputTextMultiline(
                                "descricao",
                                "Descrição do produto",
                                id_input="form-produto-input-descricao",
                                default="",
                            ),
                            MaterializeInputText(
                                "quantidade",
                                "Quantidade",
                                id_input="form-entrada-input-quantidade",
                                default="0",
                                error="",
                                _class="col s12 m6 l6",
                                _phanterpwaformvalidator_valueisdifferentof="0,00000",
                                _phanterpwaformvalidator_group="entrada",
                            ),
                            MaterializeInputText(
                                "preco_unitario",
                                "Preço de custo Unitário",
                                id_input="form-entrada-input-preco",
                                default="R$ 0,00",
                                error="",
                                _class="col s12 m6 l6",
                                _phanterpwaformvalidator_valueisdifferentof="R$ 0,00",
                                _phanterpwaformvalidator_group="entrada",
                            ),
                            materialize_total,
                            MaterializeInputText(
                                "data_registro",
                                "Data Registro",
                                id_input="form-entrada-input-data",
                                error="",
                                _class="col s12 m7 l6",
                                _phanterpwaformvalidator_isnotempty="",
                                _phanterpwaformvalidator_valueisdifferentof="__/__/____ __:__:__",
                                _phanterpwaformvalidator_isdatetime="",
                                _phanterpwaformvalidator_group="entrada",
                            ),
                            DIV(_id="entrada_preco_venda_container"),
                            DIV(
                                DIV(
                                    DIV(
                                        DIV(_class="phantergallery_progressbar-movement"),
                                        _class="phantergallery_progressbar"),
                                    _class="progressbar-form-modal",
                                    _id="progressbar-form-entrada"),
                                _class="progressbar-container-form-modal"),
                            DIV(
                                DIV(
                                    MaterializeButtonForm(
                                        "form-entrada-button-entrada",
                                        "Pré-confirmação",
                                        _class="waves-effect waves-teal",
                                        _phanterpwaformvalidator_submit="",
                                        _phanterpwaformvalidator_group="entrada"
                                    ),
                                    _class='buttons-form-container'),
                                _class="input-field col s12"),
                            _action="#",
                            _class="form-entrada",
                            _id="form-entrada",
                            _phanterpwaformvalidator_group="entrada",
                            _enctype="multipart/form-data",
                            _method="post",
                            _autocomplete="off"),
                        _class="col s12"),
                    _class="row"),
                _class='entrada-container'),
            _class="subcontainer-entrada"),
        _class="main-container-entrada"),
)

tabs = MaterializeTabs()
tabs.addTab(
    "tab1",
    "Fornecedor",
    tab1,
    actived=True,
    _id="menu_tab1",
    _class="col s4"
)
tabs.addTab(
    "tab2",
    "Produto",
    tab2,
    disabled=True,
    _id="menu_tab2",
    _class="col s4"
)
tabs.addTab(
    "tab3",
    "Entrada",
    tab3,
    disabled=True,
    _id="menu_tab3",
    _class="col s4"
)

html = CONCATENATE(
    H3(
        DIV("ESTOQUE",
            _class="phanterpwa-container"
        ),
        _class="titulo_maincontainer"
    ),
    DIV(
        DIV(
            DIV(
                DIV(
                    DIV(
                        DIV(
                            DIV(
                                H6("FORNECEDOR", _class="flow-titulo"),
                                DIV(
                                    DIV(
                                        STRONG("CNPJ: "),
                                        SPAN(
                                            _id='dados_fornecedor_estoque_cnpj',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    DIV(
                                        STRONG("Razão Social: "),
                                        SPAN(
                                            _id='dados_fornecedor_estoque_razao_social',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    DIV(
                                        STRONG("Nome Fantasia: "),
                                        SPAN(
                                            _id='dados_fornecedor_estoque_fantasia',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    DIV(
                                        STRONG("Telefone: "),
                                        SPAN(
                                            _id='dados_fornecedor_estoque_telefone',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    DIV(
                                        STRONG("Email: "),
                                        SPAN(
                                            _id='dados_fornecedor_estoque_email',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    DIV(
                                        STRONG("Municipio/UF: "),
                                        SPAN(
                                            _id='dados_fornecedor_estoque_municipio',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    _class='dados_fornecedor_esccolhido_estoque'
                                ),
                                _class="col s12 m4 l12"
                            ),
                            DIV(
                                H6("PRODUTO", _class="flow-titulo"),
                                DIV(
                                    DIV(
                                        IMG(
                                            _id="dados_produto_estoque_imagem",
                                            _src="/static/images/produtos.png"
                                        ),
                                        _class='imagem_produto_selecionado_estoque'
                                    ),
                                    DIV(
                                        DIV(
                                            STRONG("Código: "),
                                            SPAN(
                                                _id='dados_produto_estoque_codigo',
                                                _class="dados_estoque_escolhido"
                                            )
                                        ),
                                        DIV(
                                            STRONG("Produto: "),
                                            SPAN(
                                                _id='dados_produto_estoque_produto',
                                                _class="dados_estoque_escolhido"
                                            )
                                        ),
                                        _class='dados_produto_selecionado_estoque'
                                    ),
                                    _class="painel_produto_selecionado_container"
                                ),
                                _class="col s12 m4 l12"
                            ),
                            DIV(
                                H6("ENTRADA", _class="flow-titulo"),
                                DIV(
                                    DIV(
                                        STRONG("Unidade: "),
                                        SPAN(
                                            _id='dados_produto_estoque_unidade',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    DIV(
                                        STRONG("Quantidade: "),
                                        SPAN(
                                            _id='dados_entrada_quantidade',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    DIV(
                                        STRONG("Preço de custo unitário (R$): "),
                                        SPAN(
                                            _id='dados_entrada_preco',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    DIV(
                                        STRONG("Preço de custo total (R$): "),
                                        SPAN(
                                            _id='dados_entrada_preco_total',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    DIV(
                                        STRONG("Destino: "),
                                        SPAN(
                                            _id='dados_produto_estoque_destino',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    DIV(
                                        STRONG("Data Registro: "),
                                        SPAN(
                                            _id='dados_produto_estoque_data',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    DIV(
                                        STRONG("Preço de venda (R$): "),
                                        SPAN(
                                            _id='dados_entrada_preco_venda',
                                            _class="dados_estoque_escolhido"
                                        )
                                    ),
                                    _class='dados_entrada_estoque'
                                ),
                                _class="col s12 m4 l12"
                            ),
                            _class="row"
                        ),
                        DIV(
                            DIV(
                                "Concluir",
                                _id="botao_enviar_produto_estoque",
                                _class="btn waves-teal waves-effect disabled"
                            ),
                            _class='centralizar_texto'
                        ),
                        _class="main-container-produto_fornecedor_escolhido card"
                    ),
                    _class="col s12 m12 l4 push-l8"
                ),
                DIV(
                    DIV(
                        tabs,
                        _class="main-container-estoque_adicionar_no_estoque card"
                    ),
                    _class="col s12 m12 l8 pull-l4"
                ),
                _class="row"
            ),
            _class="new-container"
        ),
        _class="phanterpwa-container",
        _id="estoque_adicionar_produto_no_estoque"
    ),
    PhanterGalleryInput(
        cut_size=(256, 256),
        global_id='produto',
        zindex=2005
    ).just_cutter_panel,
    SCRIPTMINIFY("page_estoque_adicionar_produto_no_estoque();"),
)