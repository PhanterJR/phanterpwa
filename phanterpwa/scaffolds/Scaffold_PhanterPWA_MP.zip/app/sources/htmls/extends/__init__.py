
from app import (
    __author__,
    __version__ as app_version,
    __project__ as app_name,
    __path_app__ as app_folder
)
