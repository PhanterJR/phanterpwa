# -*- coding: utf-8 -*-

from phanterpwa.helpers import (
    DIV,
    LABEL,
    INPUT
)

html = DIV(
    INPUT(
        _id="map-input-§name§",
        _type="text",
        _name="§name§"),
    LABEL(
        "§label§",
        _for="map-input-§name§"),
    _id="map-container-input-§name§",
    _class="input-field")
