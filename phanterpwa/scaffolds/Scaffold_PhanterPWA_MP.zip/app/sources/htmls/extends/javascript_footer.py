# -*- coding: utf-8 -*-
from . import app_version
from phanterpwa.helpers import (
    SCRIPT,
    CONCATENATE
)
html = CONCATENATE(

)
