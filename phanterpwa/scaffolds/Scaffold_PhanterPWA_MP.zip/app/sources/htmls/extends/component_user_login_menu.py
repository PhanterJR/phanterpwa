# -*- coding: utf-8 -*-

from phanterpwa.components.left_bar import (
    ButtonLeftUserMenu,
)

html = ButtonLeftUserMenu("user")

html.addSubmenu(
    "profile",
    "Perfil",
    _class="command_user",
    _link_href="page_profile"
)

html.addSubmenu(
    "lock",
    "Bloquear",
    _class="command_user",
    _link_href="page_lock"
)

html.addSubmenu(
    "logout",
    "Sair",
    _class="command_user"
)
