# -*- coding: utf-8 -*-

from . import app_version

from phanterpwa.helpers import (
    DIV,
    IMG,
    I,
    SPAN
)

html = DIV(
    DIV(
        DIV(
            DIV(
                DIV(
                    IMG(
                        _id="url_image_user",
                        _src="/static/%s/images/user.png" %
                        (app_version),
                        _alt='user avatar'
                    ),
                    _class='cmp-bar_user-img'),
                _class='cmp-bar_user-img-container'),
            DIV(
                DIV(
                    DIV(_id="user_first_and_last_name_login", _class='cmp-bar_user-name'),
                    DIV(_id="user_role_login", _class='cmp-bar_user-role'),
                    _class='cmp-bar_user-name-role'),
                _class='cmp-bar_user-name-role-container'),
            DIV(
                DIV(
                    DIV(_class="led"),
                    _class="cmd-bar_user-expands"),
                _class="cmd-bar_user-expand-container"),
            _class="cmp-bar_user-info-container"),
        _id="toggle-cmp-bar_user",
        _class="cmp-bar_user-container black link waves-effect waves-cmp_user"),
    DIV(
        DIV(
            DIV(
                I("face", _class="material-icons"),
                SPAN("Perfil"),
                _class="option-label-menu"
            ),
            _id="cmp-bar_usermenu-option-profile",
            _class='cmp-bar_usermenu-option link waves-effect waves-cmp_user',
            _link_href="page_profile"
        ),
        DIV(
            DIV(
                I("https", _class="material-icons"),
                SPAN("Bloquear"),
                _class="option-label-menu"
            ),
            _id="cmp-bar_usermenu-option-lock",
            _class='cmp-bar_usermenu-option link waves-effect waves-cmp_user',
            _link_href="page_lock"
        ),
        DIV(
            DIV(
                I("power_settings_new", _class="material-icons"),
                SPAN("Sair"),
                _class="option-label-menu"),
            _id="cmp-bar_usermenu-option-logout",
            _class='cmp-bar_usermenu-option link waves-effect waves-cmp_user'
        ),
        _class="cmp-bar_usermenu-container"),
    _class="cmp-bar_user_and_menu-container"
)
