# -*- coding: utf-8 -*-

from phanterpwa.components.left_bar import (
    ButtonLeftMenu,
)

from phanterpwa.helpers import (
    CONCATENATE
)

html = CONCATENATE(
    ButtonLeftMenu(
        "edit_admin_auth_group",
        "Edit Group",
        "fab fa-black-tie",
        _title="Adicionar editar fabricos",
        _class="link_href",
        _link_href="page_admin_auth_group"
    )
)