# -*- coding: utf-8 -*-

from phanterpwa.components.left_bar import (
    ButtonLeftMenu,
)

html = ButtonLeftMenu(
    "principal",
    "Principal",
    "fas fa-home",
    _onclick="phanterpwapages.principal();"
)
