# -*- coding: utf-8 -*-

from phanterpwa.helpers import (
    DIV
)

from phanterpwa.components.phantergallery import (
    PhanterGalleryInput
)

html = DIV(
    PhanterGalleryInput(
        cut_size=(256, 256),
        global_id='profile',
        zindex=2000
    ),
    _class="phantergallery-image-user-container"
)
