# -*- coding: utf-8 -*-

from phanterpwa.components.left_bar import (
    ButtonLeftMenu,
)

html = ButtonLeftMenu(
    "user",
    "Início",
    "fab fa-black-tie",
)

html.addSubmenu(
    "login",
    "Login",
    _class="command_user"
)

html.addSubmenu(
    "register",
    "Criar Conta",
    _class="command_user"
)

html.addSubmenu(
    "request-password",
    "Esqueci a Senha",
    _class="command_user"
)
