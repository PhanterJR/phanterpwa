# -*- coding: utf-8 -*-

from . import app_version
from phanterpwa.helpers import (
    LINK,
    CONCATENATE
)
html = CONCATENATE(
    LINK(
        _rel="stylesheet",
        _href="/static/%s/css/fonts.min.css" %
        (app_version)
    ),
    LINK(
        _rel="stylesheet",
        _href="/static/%s/css/materialize.min.css" %
        (app_version)
    ),
    LINK(
        _rel="stylesheet",
        _href="/static/%s/css/all.min.css" %
        (app_version)
    ),
    LINK(
        _rel="stylesheet",
        _href="/static/%s/css/calendar.min.css" %
        (app_version)
    ),
    LINK(
        _rel="stylesheet",
        _href="/static/%s/css/application.min.css" %
        (app_version)
    ),
)
