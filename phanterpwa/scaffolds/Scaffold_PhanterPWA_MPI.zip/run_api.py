import os
import json
from api import flask_app
from core.config import CONFIG
current_folder = os.path.dirname(__file__)

with open("config.json", "w", encoding="utf-8") as f:
    CONFIG['PATH']['project'] = current_folder
    CONFIG['PATH']['api'] = os.path.join(current_folder, "api")
    CONFIG['PATH']['app'] = path_app = os.path.join(current_folder, "app")
    json.dump(CONFIG, f, ensure_ascii=True, indent=2)

debug = CONFIG['PROJECT']['debug']
python_env = CONFIG['ENVIRONMENT']['python']
app_server_port = CONFIG['API_SERVER']['port']
app_server_host = CONFIG['API_SERVER']['host']

if os.name == 'nt':
    if not os.path.exists("run_api.bat"):
        with open("run_api.bat", "w") as f:
            t = 'mode con: cols=120 lines=50\ncall "%s" "%s"' % \
                (python_env, os.path.join(current_folder, "run_api.py"))
            f.write(t)

with open(os.path.join(current_folder, "core", "art"), "r") as f:
    print("\n\n", f.read(), "\n\n\n")

with open('server_api.pid', 'w') as f:
    f.write(str(os.getpid()))

flask_app.logger.debug('PID process: %s' % os.getpid())
print("Api Server running...")
flask_app.debug = debug
flask_app.run(host=app_server_host, port=app_server_port)
