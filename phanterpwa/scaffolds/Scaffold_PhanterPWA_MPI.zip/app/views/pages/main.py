# -*- coding: utf-8 -*-

from . import app_version
from phanterpwa.helpers import (
    DIV
)

LINK_CARDAPIO = "/static/%s/images/cardapio.png" % (app_version)
LINK_DELIVERY = "/static/%s/images/delivery.png" % (app_version)

html = DIV(
        DIV(_class="content_pagina_principal"),
        _class='background-empresa'
)

