# -*- coding: utf-8 -*-

from phanterpwa.helpers import (
    DIV,
    H3,
    FORM,
    CONCATENATE,
    SCRIPTMINIFY
)
from phanterpwa.components.materialize import (
    MaterializeInputPassword,
    MaterializeInputHidden,
    MaterializeButtonForm
)

html = CONCATENATE(
    H3(DIV("Mudar Senha", _class="phanterpwa-container"), _class="titulo_maincontainer"),
    DIV(
        DIV(
            DIV(
                DIV(
                    DIV(
                        _id="aviso_change_password",
                        _class="simple-alerts"
                    ),
                    FORM(
                        MaterializeInputHidden(
                            "csrf_token",
                            "csrf token",
                            default="",
                            error="",
                            _phanterpwaformvalidator_isnotempty="",
                            _phanterpwaformvalidator_group="change-password",
                        ),
                        DIV(
                            MaterializeInputPassword(
                                "old_password",
                                "Senha Atual",
                                default="",
                                error="",
                                _phanterpwaformvalidator_isnotempty="",
                                _phanterpwaformvalidator_group="change-password",
                                _class="col 12"
                            ),
                            _class="row reset-css-row"
                        ),
                        DIV(
                            MaterializeInputPassword(
                                "password",
                                "Senha",
                                default="",
                                error="",
                                _phanterpwaformvalidator_isnotempty="",
                                _phanterpwaformvalidator_isequals="password_repeat",
                                _phanterpwaformvalidator_group="change-password",
                                _class="col m6 s12"
                            ),
                            MaterializeInputPassword(
                                "password_repeat",
                                "Repetir Senha",
                                default="",
                                error="",
                                _phanterpwaformvalidator_isnotempty="",
                                _phanterpwaformvalidator_isequals="password",
                                _phanterpwaformvalidator_group="change-password",
                                _class="col m6 s12"
                            ),
                            _class="row reset-css-row"
                        ),
                        DIV(
                            DIV(
                                DIV(
                                    DIV(_class="phantergallery_progressbar-movement"),
                                    _class="phantergallery_progressbar"),
                                _class="progressbar-form-modal"),
                            _class="progressbar-container-form-modal"),
                        DIV(
                            DIV(
                                MaterializeButtonForm(
                                    "change-password-ajax-button-submit",
                                    "Mudar Senha",
                                    _class="waves-effect waves-teal",
                                    _phanterpwaformvalidator_submit="",
                                    _phanterpwaformvalidator_group="change-password"
                                ),
                                _class='buttons-form-container'
                            ),
                            _class="input-field col s12"
                        ),
                        _action="#",
                        _id="form-change-password",
                        _phanterpwaformvalidator_group="change-password",
                        _class="form-change-password",
                        _enctype="multipart/form-data",
                        _method="pt",
                        _autocomplete="off"
                    ),
                    _class="phanterpwa-card-container",
                ),
                _class="card"
            ),
            _class="new-container"
        ),
        _class="phanterpwa-container"
    ),
    SCRIPTMINIFY(
        "phanterpwapages.changePassword();",
        _type="text/javascript"
    ),
)
