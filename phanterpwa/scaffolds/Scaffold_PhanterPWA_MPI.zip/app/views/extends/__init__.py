from core.config import CONFIG
app_version = CONFIG['PROJECT']['version']
app_name = CONFIG['PROJECT']['name']
app_folder = CONFIG['PATH']['app']
