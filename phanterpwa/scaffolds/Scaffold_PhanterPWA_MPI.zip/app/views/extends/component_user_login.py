from core.config import CONFIG
from phanterpwa.helpers import (
    DIV,
    IMG,
    I,
    SPAN
)
from core.internationalization import Translator_app as Translator
app_version = CONFIG['PROJECT']['version']
html = DIV(
    DIV(
        DIV(
            DIV(
                DIV(
                    IMG(
                        _id="url_image_user",
                        _src="/static/%s/images/user.png" %
                        (app_version),
                        _alt='user avatar'
                    ),
                    _class='cmp-bar_user-img'),
                _class='cmp-bar_user-img-container'),
            DIV(
                DIV(
                    DIV(_id="user_first_and_last_name_login", _class='cmp-bar_user-name'),
                    DIV(_id="user_role_login", _class='cmp-bar_user-role'),
                    _class='cmp-bar_user-name-role'),
                _class='cmp-bar_user-name-role-container'),
            DIV(
                DIV(
                    DIV(_class="led"),
                    _class="cmd-bar_user-expands"),
                _class="cmd-bar_user-expand-container"),
            _class="cmp-bar_user-info-container"),
        _id="toggle-cmp-bar_user",
        _class="cmp-bar_user-container black link waves-effect waves-cmp_user"),
    DIV(
        DIV(
            DIV(
                I("face", _class="material-icons"),
                SPAN("Profile", _phanterpwa_languages=Translator.dictionaries("Profile")),
                _phanterpwa_route="profile",
                _class="option-label-menu"
            ),
            _id="cmp-bar_usermenu-option-profile",
            _class='cmp-bar_usermenu-option link waves-effect waves-cmp_user',
            _link_href="page_profile"
        ),
        DIV(
            DIV(
                I("https", _class="material-icons"),
                SPAN("Lock", _phanterpwa_languages=Translator.dictionaries("Lock")),
                _class="option-label-menu"
            ),
            _id="cmp-bar_usermenu-option-lock",
            _class='cmp-bar_usermenu-option link waves-effect waves-cmp_user',
            _link_href="page_lock"
        ),
        DIV(
            DIV(
                I("power_settings_new", _class="material-icons"),
                SPAN("Logout", _phanterpwa_languages=Translator.dictionaries("Logout")),
                _class="option-label-menu"),
            _id="cmp-bar_usermenu-option-logout",
            _class='cmp-bar_usermenu-option link waves-effect waves-cmp_user'
        ),
        _class="cmp-bar_usermenu-container"),
    _class="cmp-bar_user_and_menu-container"
)
