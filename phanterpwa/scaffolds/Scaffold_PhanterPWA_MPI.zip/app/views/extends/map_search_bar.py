from phanterpwa.helpers import (
    DIV,
    P
)
from phanterpwa.components.materialize import (
    MaterializeSearchBar
)
search_bar = MaterializeSearchBar("§table_name§")
search_bar.showSelect()
html = DIV(
    DIV(
        P(_id="phanterpwatables-title-flow-§table_name§", _class="flow-text phanterpwatables-title-flow"),
        search_bar,
        _class="phanterpwatables-head-container"),
    DIV("§phanterpwatable_table§",
        _id="phanterpwatable-table-container-§table_name§",
        _class="phanterpwatable-table-container"),
    _id='phanterpwatable-tables-and-searchbar-§table_name§',
    _class='phanterpwatable-tables-and-searchbar')
