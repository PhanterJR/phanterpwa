from core.config import CONFIG
from phanterpwa.helpers import (
    SCRIPT,
    CONCATENATE,
    XML
)
app_version = CONFIG['PROJECT']['version']
html = CONCATENATE(
    SCRIPT(
        _src="/static/%s/js/jquery.min.js" %
        (app_version)
    ),
    SCRIPT(
        _src="/static/%s/js/materialize.min.js" %
        (app_version)
    ),
    SCRIPT(
        _src="/static/%s/js/calendar.js" %
        (app_version)
    ),
    SCRIPT(
        _src="/static/%s/js/hammer.min.js" %
        (app_version)
    ),
    SCRIPT(
        _src="/static/%s/js/touch-emulator.js" %
        (app_version)
    ),
    SCRIPT(
        _src="/static/%s/js/jquery.hammer.js" %
        (app_version)
    ),
    # SCRIPT(
    #     _src="/static/%s/js/nouislider.min.js" %
    #     (app_version)
    # ),
    SCRIPT(
        XML("import * as application from '/static/%s/js/transcrypt/application.js';" % app_version),
        _type="module"),
)
