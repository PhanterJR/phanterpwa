from core.config import CONFIG
from phanterpwa.components.left_bar import (
    LeftBarUserMenu,
)
from core.internationalization import Translator_app as Translator
from phanterpwa.helpers import (
    SPAN
)
app_version = CONFIG['PROJECT']['version']
html = LeftBarUserMenu("user", url_image_user="/static/%s/images/user.png" % (app_version))

html.addSubmenu(
    "profile",
    SPAN("Profile", _phanterpwa_languages=Translator.dictionaries("Profile")),
    _class="command_user",
    _phanterpwa_route="profile",
)

html.addSubmenu(
    "lock",
    SPAN("Lock", _phanterpwa_languages=Translator.dictionaries("Lock")),
    _class="command_user",
    _link_href="page_lock"
)

html.addSubmenu(
    "logout",
    SPAN("Logout", _phanterpwa_languages=Translator.dictionaries("Logout")),
    _class="command_user"
)
