from core.config import CONFIG
from phanterpwa.helpers import (
    DIV,
    IMG,
    I,
    H3,
    FORM
)
from phanterpwa.components.materialize import (
    MaterializeInputText,
    MaterializeInputPassword,
    MaterializeInputHidden,
    MaterializeButtonForm,
    MaterializeInputCheckBox,
    MaterializePreloaderCircle
)
from phanterpwa.components.inputs import (
    InputText,
    InputPassword,
    InputHidden
)
from core.internationalization import Translator_app as Translator
app_version = CONFIG['PROJECT']['version']

input_email = DIV(
    InputText(
        "email",
        "Email",
        error="",
        _phanterpwa_languages=Translator.dictionaries("Email"),
        _phanterpwa_form_validator=["IS_EMAIL"],
    ),
    _class="col s12")

html = DIV(
    DIV(
        DIV(
            I(_class="fas fa-times"),
            _class='phanterpwa-models-close'),
        H3(DIV("Login", _id="form-login-input-tittle-hidden-switch"),
            _class="phanterpwa-models-titulo"),
        DIV(
            DIV(
                DIV(
                    FORM(
                        DIV(
                            DIV(
                                DIV(
                                    DIV(
                                        IMG(
                                            _src="/static/%s/images/user.png" %
                                            (app_version),
                                            _id="form-login-image-user-url"),
                                        _class="form-image-user-img"),
                                    _class="form-image-user-img-container"),
                                DIV(
                                    DIV("Nome Sobrenome",
                                        _id='form-login-profile-user-name',
                                        _class="form-profile-user-name"),
                                    DIV("Usuário",
                                        _id='form-login-profile-user-role',
                                        _class="form-profile-user-role"),
                                    _class="form-profile-user-info"),
                                _class="form-profile-container"),
                            _id="form-login-image-user-container",
                            _class="form-image-user-container",
                            _style="display:none;"),
                        DIV(
                            DIV(
                                MaterializeButtonForm(
                                    "form-login-button-other-user",
                                    "Usar outra conta",
                                    _class="waves-effect waves-teal btn-small"
                                ),
                                _class='buttons-form-container'),
                            _id="form-login-button-other-user-container",
                            _class="input-field col s12",
                            _style="display:none;"),
                        InputHidden(
                            "csrf_token",
                            "csrf token",
                            error="",
                            _phanterpwa_form_validator=["IS_NOT_EMPTY"],
                        ),
                        input_email,
                        DIV(
                            InputPassword(
                                "password",
                                "Password",
                                default="",
                                error="",
                                _phanterpwa_languages=Translator.dictionaries("Password"),
                                _phanterpwa_form_validator=["IS_NOT_EMPTY"],
                            ),
                            _class="col s12 m12"),
                        MaterializeInputCheckBox(
                            "remember_me",
                            "Mantenha-me conectado",
                            id_input="form-login-input-remember_me"
                        ),
                        DIV(
                            MaterializePreloaderCircle('profile-ajax', "big"),
                            _class='phanterpwa-form-captcha-ajax-container ',
                            _id="phanterpwa-form-captcha-ajax-container-user_login"),
                        DIV(
                            DIV(
                                DIV(
                                    DIV(_class="phantergallery_progressbar-movement"),
                                    _class="phantergallery_progressbar"),
                                _class="progressbar-form-modal",
                                _id="progressbar-form-user"),
                            _class="progressbar-container-form-modal"),
                        DIV(
                            DIV(
                                MaterializeButtonForm(
                                    "user_login-ajax-button-submit",
                                    "Login",
                                    _phanterpwa_languages=Translator.dictionaries("Login"),
                                    _phanterpwa_form_submit_button=True,
                                    _class="waves-effect waves-teal",
                                ),
                                MaterializeButtonForm(
                                    "user_login-ajax-button-register",
                                    "Create an account",
                                    _phanterpwa_languages=Translator.dictionaries("Create an account"),
                                    _class="waves-effect waves-teal"
                                ),
                                MaterializeButtonForm(
                                    "user_login-ajax-button-request_password",
                                    "Recover password",
                                    _phanterpwa_languages=Translator.dictionaries("Recover password"),
                                    _class="waves-effect waves-teal"
                                ),
                                _class='phanterpwa-form-buttons-container'
                            ),
                            _class="input-field col s12"
                        ),
                        _action="#",
                        _id="user_login",
                        _class="form-login",
                        _enctype="multipart/form-data",
                        _method="post",
                        _autocomplete="off"
                    ),
                    _class="col s12"
                ),
                _class="row"
            ),
            _class='container-login'
        ),
        _class="subcontainer-login"
    ),
    _id="modal_user_login",
    _class="main-container-login modal"
)
