from phanterpwa.helpers import (
    DIV,
    LABEL,
    INPUT
)

html = DIV(
    INPUT(
        _id="map-input-slide-§name§",
        _type="text",
        _name="§name§"),
    LABEL(
        "§label§",
        _for="map-input-slide-§name§"),
    _id="map-container-input-slide-§name§",
    _class="input-field")
