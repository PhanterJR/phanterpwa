from phanterpwa.helpers import (
    DIV,
    I,
    SPAN
)
from core.internationalization import Translator_app as Translator
html = DIV(
    DIV(
        DIV(
            DIV(
                DIV(_class="led"),
                _class="cmd-bar_user-expands"),
            _class="cmd-bar_user-expand-container"),
        DIV("START",
            _class="cmd-bar-start",
            _phanterpwa_languages=Translator.dictionaries("START")),
        _id="toggle-cmp-bar_user",
        _class="cmp-bar_user-container black link waves-effect waves-cmp_user"),
    DIV(
        DIV(
            DIV(
                I("power_settings_new", _class="material-icons"),
                SPAN("Login", _phanterpwa_languages=Translator.dictionaries("Login")),
                _class="option-label-menu"
            ),
            _id="cmp-bar_usermenu-option-login",
            _class='cmp-bar_usermenu-option link waves-effect waves-cmp_user'
        ),
        DIV(
            DIV(
                I("person_add", _class="material-icons"),
                SPAN("Create an account", _phanterpwa_languages=Translator.dictionaries("Create an account")),
                _class="option-label-menu"
            ),
            _id="cmp-bar_usermenu-option-register",
            _class='cmp-bar_usermenu-option link waves-effect waves-cmp_user'
        ),
        DIV(
            DIV(
                I("lock", _class="material-icons"),
                SPAN("Recover password", _phanterpwa_languages=Translator.dictionaries("Recover password")),
                _class="option-label-menu"
            ),
            _id="cmp-bar_usermenu-option-request_password",
            _class='cmp-bar_usermenu-option link waves-effect waves-cmp_user'
        ),
        _class="cmp-bar_usermenu-container"),
    _class="cmp-bar_user_and_menu-container"
)
