from core.config import CONFIG
from phanterpwa.helpers import (
    LINK,
    CONCATENATE
)
app_version = CONFIG['PROJECT']['version']
html = CONCATENATE(
    LINK(
        _rel="stylesheet",
        _href="/static/%s/css/fonts.css" %
        (app_version)
    ),
    LINK(
        _rel="stylesheet",
        _href="/static/%s/css/materialize.min.css" %
        (app_version)
    ),
    LINK(
        _rel="stylesheet",
        _href="/static/%s/css/all.min.css" %
        (app_version)
    ),
    LINK(
        _rel="stylesheet",
        _href="/static/%s/css/calendar.min.css" %
        (app_version)
    ),
    LINK(
        _rel="stylesheet",
        _href="/static/%s/css/application.css" %
        (app_version)
    ),
)
