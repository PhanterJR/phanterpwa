from phanterpwa.helpers import (
    DIV,
    H3,
    FORM,
    I
)
from phanterpwa.components.materialize import (
    MaterializeInputText,
    MaterializeInputPassword,
    MaterializePreloaderCircle,
    MaterializeInputHidden,
    MaterializeButtonForm
)
from phanterpwa.components.inputs import (
    InputText,
    InputPassword,
    InputHidden
)
from core.internationalization import Translator_app as Translator
html = DIV(
    DIV(
        DIV(
            I(_class="fas fa-times"),
            _class='phanterpwa-models-close'),
        H3("Criar nova conta", _class="phanterpwa-models-titulo"),
        DIV(
            DIV(
                DIV(
                    FORM(
                        InputHidden(
                            "csrf_token",
                            "csrf token",
                            error="",
                            _phanterpwa_form_validator=["IS_NOT_EMPTY"],
                        ),
                        DIV(
                            DIV(
                                InputText(
                                    "first_name",
                                    "Name",
                                    error="",
                                    _phanterpwa_languages=Translator.dictionaries("Name"),
                                    _phanterpwa_form_validator=["IS_NOT_EMPTY"],
                                ),
                                _class="col s12 m6"
                            ),
                            DIV(
                                InputText(
                                    "last_name",
                                    "Last Name",
                                    error="",
                                    _phanterpwa_languages=Translator.dictionaries("Last Name"),
                                    _phanterpwa_form_validator=["IS_NOT_EMPTY"],
                                ),
                                _class="col s12 m6"),
                            _class="row reset-css-row"),
                        DIV(
                            DIV(
                                InputText(
                                    "email",
                                    "Email",
                                    error="",
                                    _phanterpwa_languages=Translator.dictionaries("Email"),
                                    _phanterpwa_form_validator=["IS_EMAIL"],
                                ),
                                _class="col s12"),
                            _class="row reset-css-row"
                        ),
                        DIV(
                            DIV(
                                InputPassword(
                                    "password",
                                    "Password",
                                    default="",
                                    error="",
                                    _phanterpwa_languages=Translator.dictionaries("Password"),
                                    _phanterpwa_form_validator=["IS_NOT_EMPTY", "IS_EQUALS:#phanterpwa-input-password_repeat"],
                                ),
                                _class="col s12 m6"),
                            DIV(
                                InputPassword(
                                    "password_repeat",
                                    "Password Repeat",
                                    default="",
                                    error="",
                                    _phanterpwa_languages=Translator.dictionaries("Password Repeat"),
                                    _phanterpwa_form_validator=["IS_NOT_EMPTY", "IS_EQUALS:#phanterpwa-input-password"],
                                ),
                                _class="col s12 m6"),
                            _class="row reset-css-row"
                        ),
                        DIV(
                            MaterializePreloaderCircle('profile-ajax', "big"),
                            _class='phanterpwa-form-captcha-ajax-container ',
                            _id="phanterpwa-form-captcha-ajax-container-user_register"),
                        DIV(
                            DIV(
                                DIV(
                                    DIV(_class="phantergallery_progressbar-movement"),
                                    _class="phantergallery_progressbar"),
                                _id="progressbar-form-user_register",
                                _class="progressbar-form-modal"),
                            _class="progressbar-container-form-modal"),
                        DIV(
                            DIV(
                                MaterializeButtonForm(
                                    "user_register-ajax-button-submit",
                                    "Create an account",
                                    _phanterpwa_languages=Translator.dictionaries("Create an account"),
                                    _phanterpwa_form_submit_button=True,
                                    _class="waves-effect waves-teal"
                                ),
                                MaterializeButtonForm(
                                    "user_register-ajax-button-login",
                                    "I already have an account",
                                    _phanterpwa_languages=Translator.dictionaries("I already have an account"),
                                    _class="waves-effect waves-teal"
                                ),
                                MaterializeButtonForm(
                                    "user_register-ajax-button-request_password",
                                    "Recover password",
                                    _phanterpwa_languages=Translator.dictionaries("Recover password"),
                                    _class="waves-effect waves-teal"
                                ),
                                _class='phanterpwa-form-buttons-container'
                            ),
                            _class="input-field col s12"
                        ),
                        _action="#",
                        _id="user_register",
                        _class="form-user_register",
                        _enctype="multipart/form-data",
                        _method="post",
                        _autocomplete="off"
                    ),
                    _class="col-12"
                ),
                _class="row"
            ),
            _class='container-user_register'
        ),
        _class="subcontainer-user_register"
    ),
    _id="modal_user_register",
    _class="main-container-user_register modal"
)
