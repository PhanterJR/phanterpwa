from phanterpwa.components.left_bar import (
    LeftBarMenu,
)
from core.internationalization import Translator_app as Translator
from phanterpwa.helpers import (
    SPAN
)
html = LeftBarMenu(
    "user",
    SPAN("Start", _phanterpwa_languages=Translator.dictionaries("Start")),
    "fas fa-user",
)

html.addSubmenu(
    "login",
    SPAN("Login", _phanterpwa_languages=Translator.dictionaries("Login")),
    _class="command_user"
)

html.addSubmenu(
    "register",
    SPAN("Create an account", _phanterpwa_languages=Translator.dictionaries("Create an account")),
    _class="command_user"
)

html.addSubmenu(
    "request_password",
    SPAN("Recover password", _phanterpwa_languages=Translator.dictionaries("Recover password")),
    _class="command_user"
)
