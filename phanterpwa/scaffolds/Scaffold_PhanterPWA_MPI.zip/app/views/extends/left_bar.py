from phanterpwa.helpers import (
    SPAN
)
from phanterpwa.components.left_bar import (
    LeftBarButton,
)
from core.internationalization import Translator_app as Translator
html = LeftBarButton(
    "principal",
    SPAN("Home", _phanterpwa_languages=Translator.dictionaries("Home")),
    "fas fa-home",
    _phanterpwa_route="main"
)
