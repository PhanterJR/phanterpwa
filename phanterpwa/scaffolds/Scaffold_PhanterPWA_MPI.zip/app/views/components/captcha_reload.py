from phanterpwa.helpers import (DIV, I)

html = DIV(
    DIV("Conection Fail!", _id="captcha_reload_conection_fail_messagem"),
    DIV(
        DIV(I(_class="fas fa-redo-alt"), _id="captcha_reload_conection_icon"),
        DIV("Try again!", _id="captcha_reload_conection_try_again_messagem"),
        _class="captcha_reload_conection_button link"
    ),
    _class="captcha_reload_conection_container"
)
