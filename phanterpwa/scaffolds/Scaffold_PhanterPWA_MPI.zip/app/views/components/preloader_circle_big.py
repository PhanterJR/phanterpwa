# -*- coding: utf-8 -*-

from phanterpwa.components.materialize import (
    MaterializePreloaderCircle,
)
html = MaterializePreloaderCircle('profile-ajax', "big")
