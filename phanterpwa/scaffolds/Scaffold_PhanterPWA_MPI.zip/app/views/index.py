from core.config import CONFIG
app_version = CONFIG['PROJECT']['version']
app_name = CONFIG['PROJECT']['name']


from phanterpwa.helpers import (
    DIV,
    A,
    I,
    HTML,
    HEAD,
    BODY,
    META,
    TITLE,
    NAV,
    UL,
    LI,
    MAIN,
    FOOTER,
    SPAN,
    XML
)

from .extends.left_bar import html as MENU_PRINCIPAL_LEFT_BAR
from .extends.svg_logo import html as SVG_LOGO
from .extends.javascript_head import html as JAVASCRIPT_HEAD
from .extends.css_head import html as CSS_HEAD
from .extends.favicons import html as FAVICONS
from .components.preloader_circle_big import html as LOAD_BIG


html = HTML(
    HEAD(
        TITLE(app_name),
        META(_charset="utf-8"),
        META(
            _name="viewport",
            _content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"
        ),
        META(_name="aplication-name", _content="Flask, Nginx, Cordova"),
        META(_name="aplication-version", _content=app_version),
        META(_name="msapplication-tap-highlight", _content="no"),
        CSS_HEAD,
        JAVASCRIPT_HEAD,
        FAVICONS
    ),
    BODY(
        DIV(_id="top_alert"),
        NAV(
            DIV(
                DIV(
                    DIV(
                        I(
                            "menu",
                            _class="large material-icons"
                        ),
                        _id="menu-button-main-page",
                        _class="main-menu-layout waves-effect waves-cmp_user"),
                    _class='link'),
                DIV(
                    DIV(
                        XML(SVG_LOGO),
                        _class="logo-svg"
                    ),
                    _class="brand-logo link"
                ),
                UL(
                    LI(
                        DIV(
                            DIV(

                                _id="user_login_and_menu-container",
                            ),
                            _class="cmp_user_login-container"
                        )
                    ),
                    _id="nav-mobile",
                    _class="right hide-on-med-and-down"
                ),
                _class="nav-wrapper"
            ),
            _class="grey darken-4 main-nav"
        ),
        DIV(
            DIV(
                DIV(
                    DIV(
                        DIV(
                            DIV(
                                _id="materialize-component-left-menu-user"),
                            _id="echo-user-cmp-login-menu"),
                        _id="options-top-main-bar-left"),
                    DIV(
                        MENU_PRINCIPAL_LEFT_BAR,
                        _id="options-middle-main-bar-left"),
                    DIV(
                        _id="options-bottom-main-bar-left"),
                    _id="left_bar"),
                _class="left_bar-container"),
            MAIN(
                DIV(
                    LOAD_BIG,
                    _style="width:100%; text-align: center; padding-top: 100px;"
                ),
                _id="main-container"
            ),
            _class="main-and-left_bar"
        ),
        DIV(
            DIV(_id="phanterpwa-toolbar"),
            _id="modal-container"),
        FOOTER(
            DIV(
                DIV(
                    DIV(
                        DIV(_class="phanterpwa_progressbar-movement"),
                        _class="phanterpwa_progressbar"
                    ),
                    _id="main-progress-bar",
                    _class="main-progress-bar enabled"
                ),
                _class="main-progress-bar-container"
            ),
            DIV(
                DIV(_class="row"),
                _class='container'
            ),
            DIV(
                DIV(
                    SPAN("Conexão Didata © 2011-2018", _id="conexao_year"),
                    A(
                        "PhanterJR",
                        _class="grey-text text-lighten-4 right",
                        _href="#!"
                    ),
                    _class="container"
                ),
                _class="footer-copyright grey darken-3"
            ),
            _class="page-footer main-footer grey darken-4"
        ),
    ),
    _lang="pt-BR"
)
