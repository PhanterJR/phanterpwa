import routes
import config
import phanterpwa
import left_bar
import cmp_auth_user
from org.transcrypt.stubs.browser import __pragma__
__pragma__("alias", "jQuery", "$")
__pragma__("skip")
jQuery = window = document = localStorage = null = js_undefined = 0
__pragma__("noskip")


if config.CONFIG['PROJECT']['debug'] is True:
    __pragma__('jsiter')
    setup_jquery = {
        'cache': False
    }
    __pragma__('nojsiter')

    jQuery.ajaxSetup(setup_jquery)


def ready():
    phanterpwa.route("main")
    phanterpwa.start_progressbar()
    phanterpwa.getClientToken(lambda: cmp_auth_user.start())
    left_bar.start()


jQuery(document).ajaxComplete(
)
jQuery(document).ready(ready)
