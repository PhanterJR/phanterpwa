import config
import routes
# pragmas

from org.transcrypt.stubs.browser import __pragma__
__pragma__('alias', "jQuery", "$")
__pragma__('skip')

# it is ignored on transcrypt
window = jQuery = console = document = localStorage = \
    sessionStorage = this = JSON = js_undefined = navigator = __new__ = Date = 0

__pragma__('noskip')

__pragma__('kwargs')


class XmlConstructor():
    def __init__(self, tag, singleton, *content, **attributes):
        self.tag = tag
        self.singleton = singleton
        self.content = content
        self.attributes = attributes

    @property
    def tag(self):
        return self._tag

    @tag.setter
    def tag(self, tag):
        self._tag = tag

    @property
    def singleton(self):
        return self._singleton

    @singleton.setter
    def singleton(self, singleton):
        if isinstance(singleton, bool):
            self._singleton = singleton
        else:
            raise TypeError("The singleton must be bool, given: {0}".format(str(singleton)))

    def xml(self):
        if (self.singleton is True):
            self.el = jQuery("<{0}>".format(self.tag))
        else:
            self.el = jQuery("<{0}></{0}>".format(str(self.tag)))
            for c in self.content:
                if isinstance(c, str):
                    self.el.append(jQuery("<div/>").text(c).html())
                elif isinstance(c, XmlConstructor):
                    self.el.append(c.jquery())
                else:
                    self.el.append(c)
        for t in self.attributes.keys():
            if t.startswith("_"):
                self.el.attr(t[1:], self.attributes[t])

        return self.el[0].outerHTML

    def __str__(self):
        return self.xml()

    def jquery(self):
        self.xml()
        return self.el

    @staticmethod
    def tagger(tag, singleton=False):
        return lambda *content, **attributes: XmlConstructor(tag, singleton, *content, **attributes)


class XML(XmlConstructor):
    def __init__(self, *content):
        XmlConstructor.__init__(self, '', False, *content)

    def xml(self):
        html = ""
        for c in self.content:
            if isinstance(c, str):
                html += c
            elif isinstance(c, XmlConstructor):
                html += c.xml()
            else:
                html += c
        return html

    def jquery(self):
        html = self.xml()
        return html


class CONCATENATE(XmlConstructor):
    def __init__(self, *content):
        XmlConstructor.__init__(self, '', False, *content)

    def xml(self):
        html = ""
        for c in self.content:
            if isinstance(c, str):
                html += jQuery("<div/>").text(c).html()
            elif isinstance(c, XmlConstructor):
                html += c.xml()
            else:
                html += c
        return html

    def jquery(self):
        html = self.xml()
        return html


__pragma__('nokwargs')


remoteAjaxList = set()

API_SERVER_ADDRESS = config.CONFIG["CONFIGJS"]['api_server_address']


def addEventProgressBar(event_name):
    progress_bar = jQuery("#main-progress-bar")
    events = progress_bar.attr("events")
    if events is js_undefined:
        progress_bar.attr("events", JSON.stringify([event_name]))
    else:
        events = set(JSON.parse(events))
        events.add(event_name)
        events = list(events)
        progress_bar.attr("events", JSON.stringify(events))


def removeEventProgressBar(event_name):
    progress_bar = jQuery("#main-progress-bar")
    events = progress_bar.attr("events")
    if events is not js_undefined:
        events = set(JSON.parse(events))
        events.remove(event_name)
        events = JSON.stringify(list(events))
        if events != "[]":
            progress_bar.attr("events", events)
        else:
            progress_bar.removeAttr("events")


def start_progressbar():
    def check_progressbar():
        progress_bar = jQuery("#main-progress-bar")
        events = progress_bar.attr('events')
        if events is not js_undefined:
            progress_bar.addClass("enabled")
        else:
            progress_bar.removeClass("enabled")

    window.setInterval(check_progressbar, 1000)


def getClientToken(callback=None):
    addEventProgressBar("getClientToken")

    def onComplete(data, ajax_status):
        print("eitcha")
        removeEventProgressBar("getClientToken")
        if ajax_status == "success":
            auth_user = data.responseJSON.auth_user
            if (auth_user == "anonymous") or (auth_user == "logout"):
                sessionStorage.removeItem("Authorization")
                sessionStorage.removeItem("auth_user")
                if callback is not None:
                    print("callback")
                    callback()
            c_token = data.responseJSON.client_token
            if (c_token is not js_undefined):
                localStorage.setItem("Client-token", c_token)
        else:
            if data.status == 0:
                print("Sem resposta do servidor")
            elif data.status == 400:
                localStorage.removeItem("Client-token")
                sessionStorage.removeItem("Authorization")
                sessionStorage.removeItem("auth_user")
    client_token = localStorage.getItem("Client-token")
    authorization = sessionStorage.getItem("Authorization")
    url = API_SERVER_ADDRESS + '/api/client/'
    __pragma__('jsiter')
    ajax_param = {
        'url': url,
        'type': "GET",
        'crossOrigin': True,
        'complete': onComplete,
        'datatype': 'json',
        'headers': {
            'Cache-Control': 'no-store, must-revalidate, no-cache, max-age=0',
            'Application': config.CONFIG['PROJECT']['name'],
            'Application-version': config.CONFIG['PROJECT']['version']
        }
    }
    if client_token is not None:
        ajax_param['headers']['Client-token'] = client_token
    else:
        sessionStorage.removeItem("Authorization")
        sessionStorage.removeItem("auth_user")
    if authorization is not None:
        ajax_param['headers']['Authorization'] = authorization
    else:
        sessionStorage.removeItem("Authorization")
        sessionStorage.removeItem("auth_user")
    __pragma__('nojsiter')

    remoteAjaxList.add("getClientToken")
    return jQuery.ajax(ajax_param)


def getSignForm(identify_form, onComplete):
    addEventProgressBar("getSignForm")
    client_token = localStorage.getItem("Client-token")
    authorization = sessionStorage.getItem("Authorization")
    identify_form = identify_form
    url = API_SERVER_ADDRESS + '/api/signforms/' + identify_form
    __pragma__('jsiter')
    ajax_param = {
        'url': url,
        'type': "GET",
        'crossOrigin': True,
        'complete': onComplete,
        'success': lambda: removeEventProgressBar("getSignForm"),
        'error': lambda: removeEventProgressBar("getSignForm"),
        'datatype': 'json',
        'headers': {
            'Cache-Control': 'no-store, must-revalidate, no-cache, max-age=0',
            'Application': config.CONFIG['PROJECT']['name'],
            'Application-version': config.CONFIG['PROJECT']['version']
        }
    }
    if client_token is not None:
        ajax_param['headers']['Client-token'] = client_token
    if authorization is not None:
        ajax_param['headers']['Authorization'] = authorization
    __pragma__('nojsiter')
    jQuery.ajax(ajax_param)


def postSignForm(form, onComplete):
    addEventProgressBar("postSignForm")
    client_token = localStorage.getItem("Client-token")
    authorization = sessionStorage.getItem("Authorization")

    url = API_SERVER_ADDRESS + '/api/signforms/' + form['id_form']
    __pragma__('jsiter')
    ajax_param = {
        'url': url,
        'type': "POST",
        'data': form,
        'complete': onComplete,
        'success': lambda: removeEventProgressBar("postSignForm"),
        'error': lambda: removeEventProgressBar("postSignForm"),
        'datatype': 'json',
        'headers': {
            'Cache-Control': 'no-store, must-revalidate, no-cache, max-age=0',
            'Application': config.CONFIG['PROJECT']['name'],
            'Application-version': config.CONFIG['PROJECT']['version']
        }
    }
    if client_token is not None:
        ajax_param['headers']['Client-token'] = client_token
    if authorization is not None:
        ajax_param['headers']['Authorization'] = authorization
    __pragma__('nojsiter')
    jQuery.ajax(ajax_param)


def POST(url, form, onComplete):
    date_stamp = __new__(Date().getTime())
    addEventProgressBar("POST_" + date_stamp)
    client_token = localStorage.getItem("Client-token")
    authorization = sessionStorage.getItem("Authorization")

    __pragma__('jsiter')
    ajax_param = {
        'url': url,
        'type': "POST",
        'data': form,
        'complete': onComplete,
        'success': lambda: removeEventProgressBar("POST_" + date_stamp),
        'error': lambda: removeEventProgressBar("POST_" + date_stamp),
        'datatype': 'json',
        'crossDomain': True,
        'headers': {
            'Cache-Control': 'no-store, must-revalidate, no-cache, max-age=0',
            'Application': config.CONFIG['PROJECT']['name'],
            'Application-version': config.CONFIG['PROJECT']['version']
        }
    }
    if client_token is not None:
        ajax_param['headers']['Client-token'] = client_token
    if authorization is not None:
        ajax_param['headers']['Authorization'] = authorization
    ISTYPEOF = __pragma__("js", "{}", "form instanceof FormData")
    if ISTYPEOF:
        ajax_param['processData'] = False
        ajax_param['contentType'] = False
    __pragma__('nojsiter')
    jQuery.ajax(ajax_param)

def route_links(): 
    def route_link(el):
        ro = jQuery(el).attr("phanterpwa_route")
        jQuery(el).off("click.route").on("click.route", lambda: route(ro))
    jQuery("[phanterpwa_route]").each(lambda: route_link(this))


def route(r):
    console.log(routes.routes)
    console.log(r)
    route_links()
    if r in routes.routes:
        routes.routes[r]()
    else:
        console.log("roteamento de '" + r + "' falhou!")


def captcha(id_form_container, id_input_csrf, id_captcha_container):

    id_form = id_form_container[1:]
    jQuery("#phanterpwa-input-csrf_token").val("").trigger("keyup")

    def reloadCaptcha(id_captcha_container, html, signature):
        jQuery(id_captcha_container).html(html).phanterpwaLanguage()
        jQuery(
            ".captcha-option"
        ).off(
            "click.captcha-option" + id_captcha_container[1:]
        ).on(
            "click.captcha-option" + id_captcha_container[1:], lambda: actionClickCaptchaOption(this, signature)
        )

    def onCaptchaFailConection(id_captcha_container, id_form):
        def callbackLoad():
            jQuery(
                id_captcha_container + " #captcha_reload_conection_fail_messagem"
            ).phanterpwaTranslate(
                "pt-BR", "A Conexão Falhou!"
            )
            jQuery(
                id_captcha_container + " #captcha_reload_conection_try_again_messagem"
            ).phanterpwaTranslate(
                "pt-BR", "Tente novamente"
            )
            button = jQuery(id_captcha_container + " .captcha_reload_conection_button")
            button.off(
                "click.captcha_reload_conection_button" + id_captcha_container[1:]
            ).on(
                "click.captcha_reload_conection_button" + id_captcha_container[1:],
                lambda: jQuery(id_captcha_container).load("/components/preloader_circle_big.html",
                    lambda: getSignForm(id_form, getSignFormOnComplete)
                )
            )

        jQuery(
            id_captcha_container
        ).load(
            "/components/captcha_reload.html",
            callbackLoad
        )

    def getSignFormOnComplete(data, ajax_status):
        if ajax_status == "success":
            if data.responseJSON.status == "OK":
                signature = data.responseJSON.signature
                html = data.responseJSON.captcha
                reloadCaptcha(id_captcha_container, html, signature)
        else:
            if data.status == 0:
                onCaptchaFailConection(id_captcha_container, id_form)

    def actionClickCaptchaOption(el, signature):
        user_choice = jQuery(el).attr("token_option")
        signature = signature
        id_form = jQuery(el).attr("id_captcha")
        __pragma__('jsiter')
        form = {
            'user_choice': user_choice,
            'signature': signature,
            'id_form': id_form,
        }
        __pragma__('nojsiter')

        def postSignFormOnComplete(data, ajax_status):
            if ajax_status == "success":
                html = data.responseJSON.captcha
                csrf = data.responseJSON.csrf
                jQuery(id_input_csrf).val(csrf)
                jQuery(id_captcha_container).html(html)
                jQuery(id_form_container).trigger("keyup")
            else:
                if data.status == 0:
                    onCaptchaFailConection(id_captcha_container, id_form)
                else:
                    signature = data.responseJSON.signature
                    html = data.responseJSON.captcha
                    reloadCaptcha(id_captcha_container, html, signature)
                jQuery(id_input_csrf).val("")
                jQuery(id_form_container).trigger("keyup")
        jQuery(id_captcha_container).load("/components/preloader_circle_big.html",
            lambda: postSignForm(form, postSignFormOnComplete)
        )
    jQuery(id_captcha_container).load("/components/preloader_circle_big.html",
        lambda: getSignForm(id_form, getSignFormOnComplete)
    )


def translate(jQuery_el, browser_lang, new_el_source):
    userLang = navigator.language or navigator.userLanguage
    if browser_lang == userLang:
        jQuery_el.html(new_el_source)
    return jQuery_el


def translate_phanterpwalanguage(jQuery_el):
    userLang = navigator.language or navigator.userLanguage

    def eachElement(el):
        langs = dict(JSON.parse(jQuery(el).attr("phanterpwa_languages")))
        content = jQuery(el).text()
        content = content.strip()
        if userLang in langs:
            if content in langs[userLang]:
                jQuery(el).text(langs[userLang][content])

    jQuery(jQuery_el).find("[phanterpwa_languages]").each(lambda: eachElement(this))
    return jQuery_el


def validateForm(el_form):

    def onChange(el_form):
        id_form = el_form.attr("id")
        all_validate = list()

        def validatephanterpwainput(el):
            validate_test_pass = list()
            validate_test = list(JSON.parse(jQuery(el).attr("phanterpwa_form_validator")))
            input_name = jQuery(el).attr("name")
            value_for_validate = jQuery(el).val()
            for x in validate_test:
                if x == "IS_NOT_EMPTY":
                    if (value_for_validate is js_undefined) or \
                        (value_for_validate is None) or (value_for_validate == ""):
                        validate_test_pass.append(False)
                    else:
                        validate_test_pass.append(True)
                if x.startswith("IS_EQUALS") and ":" in x:
                    comp = jQuery(x[10:]).val()
                    if comp is value_for_validate:
                        validate_test_pass.append(True)
                    else:
                        validate_test_pass.append(False)
                if x == "IS_EMAIL":
                    if "@" in value_for_validate:
                        REGEX_BODY = __pragma__(
                            'js',
                            '{}',
                            r'/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([_a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/'
                        )
                        if REGEX_BODY.test(value_for_validate):
                            validate_test_pass.append(True)
                        else:
                            validate_test_pass.append(False)
                    else:
                        validate_test_pass.append(False)
            if all(validate_test_pass):
                all_validate.append(True)
                jQuery("#phanterpwa-input-check-" + input_name).removeClass("no_pass")
            else:
                jQuery("#phanterpwa-input-check-" + input_name).addClass("no_pass")
                all_validate.append(False)
            if all(all_validate):
                jQuery("#" + id_form + " [phanterpwa_form_submit_button]").removeAttr("disabled")
            else:
                jQuery("#" + id_form + " [phanterpwa_form_submit_button]").attr("disabled", "disabled")

        el_input = jQuery("#" + id_form + " [phanterpwa_form_validator]")
        submit_button = jQuery("#" + id_form + " [phanterpwa_form_submit_button]")
        submit_button.attr("disabled", "disabled")
        el_input.each(lambda: validatephanterpwainput(this))
        print(all_validate)
    jQuery(el_form).on('change, keyup', lambda: onChange(el_form))
    onChange(el_form)


jQuery.fn.phanterpwaTranslate = lambda browser_lang, new_el_source: translate(this, browser_lang, new_el_source)

jQuery.fn.phanterpwaLanguage = lambda: translate_phanterpwalanguage(this)

jQuery.fn.phanterpwaFormValidator = lambda: validateForm(this)
