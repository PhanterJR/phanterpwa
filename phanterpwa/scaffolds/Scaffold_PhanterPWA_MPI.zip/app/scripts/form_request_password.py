import phanterpwa

from org.transcrypt.stubs.browser import __pragma__
__pragma__('alias', "jQuery", "$")
__pragma__('skip')
jQuery = this = M = __new__ = FormData = js_undefined = sessionStorage = JSON = 0
__pragma__('noskip')

SPAN = phanterpwa.XmlConstructor.tagger("span")


def start():
    phanterpwa.captcha(
        "#user_request_password",
        "#phanterpwa-input-csrf_token",
        "#phanterpwa-form-captcha-ajax-container-user_request_password")

    def onSubmit():
        jQuery("#user_request_password .phanterpwa-materialize-input-error").removeClass('enabled').text("")

        def onComplete(data, ajax_status):
            if ajax_status == "success":
                json = data.responseJSON
                authorization = json.authorization
                auth_user = json.auth_user
                sessionStorage.setItem("Authorization", authorization)
                sessionStorage.setItem("auth_user", JSON.stringify(auth_user))
                message = SPAN("Account created successfully!").jquery().phanterpwaTranslate(
                    'pt-BR',
                    "<span>Conta criada com sucesso!</span>"
                )
                M.toast({'html': message[0]})
            else:
                if data.status == 400:
                    message = SPAN("Please, check your form.").jquery().phanterpwaTranslate(
                        'pt-BR',
                        SPAN("Por favor, cheque seu formulário.").xml()
                    )
                    M.toast({'html': message[0]})
                    phanterpwa.captcha(
                        "#user_request_password",
                        "#phanterpwa-input-csrf_token",
                        "#phanterpwa-form-captcha-ajax-container-user_request_password")
                    json = data.responseJSON
                    errors = dict(json['errors'])
                    if errors is not js_undefined:
                        for x in errors.keys():
                            id_error = "#phanterpwa-materialize-input-error-" + x
                            message = SPAN(errors[x]).xml()
                            jQuery(id_error).html(message).addClass("enabled")

            print('form send')
        formdata = __new__(FormData(jQuery("#user_request_password")[0]))
        url = phanterpwa.API_SERVER_ADDRESS + "/api/auth/request-password/"
        phanterpwa.POST(url, formdata, onComplete)

    jQuery("#user_request_password").phanterpwaLanguage().phanterpwaFormValidator()
    jQuery(
        "#user_request_password-ajax-button-submit"
    ).off(
        "click.user_request_password_submit"
    ).on(
        "click.user_request_password_submit",
        onSubmit
    )
