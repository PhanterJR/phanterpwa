from org.transcrypt.stubs.browser import __pragma__
__pragma__('alias', "jQuery", "$")
__pragma__('skip')
jQuery = window = 0
__pragma__('noskip')


def open_close_menu():
    opened_menu = jQuery("#left_bar").hasClass("enabled")
    opened_submenu = jQuery("#left_bar").hasClass("enabled_submenu")
    if (opened_menu and opened_submenu):
        jQuery("#left_bar").removeClass("enabled")
        jQuery("#left_bar, #menu-button-main-page").removeClass("enabled_submenu")
        jQuery("#menu-button-main-page").removeClass("enabled")
        jQuery(".phanterpwa-component-left_bar, .cmp-bar_user_and_menu-container").removeClass("enabled")
    elif (opened_menu):
        jQuery("#left_bar").removeClass("enabled")
        jQuery("#left_bar, #menu-button-main-page").removeClass("enabled_submenu")
        jQuery("#menu-button-main-page").removeClass("enabled")
        jQuery(".phanterpwa-component-left_bar, .cmp-bar_user_and_menu-container").removeClass("enabled")
    elif (opened_submenu):
        with_screen = jQuery(window).width()
        if int(with_screen) < 992:
            jQuery("#left_bar").removeClass("enabled")
            jQuery("#left_bar, #menu-button-main-page").removeClass("enabled_submenu")
            jQuery("#menu-button-main-page").removeClass("enabled")
            jQuery(".phanterpwa-component-left_bar, .cmp-bar_user_and_menu-container").removeClass("enabled")
        else:
            jQuery("#left_bar").addClass("enabled")
            jQuery("#menu-button-main-page").addClass("enabled")
    else:
        jQuery("#left_bar").addClass("enabled")
        jQuery("#menu-button-main-page").addClass("enabled")


def start():
    jQuery(
        "#menu-button-main-page"
    ).off(
        "click.button_menu_left"
    ).on(
        "click.button_menu_left",
        open_close_menu
    )
