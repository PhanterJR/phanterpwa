from org.transcrypt.stubs.browser import __pragma__
import route_main
import route_profile
__pragma__('jsiter')
routes = {
    'main': route_main.start,
    'profile': route_profile.start,

}
__pragma__('nojsiter')
