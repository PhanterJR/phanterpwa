# created automatically in 'D:\Github\Scaffold_PhanterPWA_MPI\core\builder.py'
# open config.ini and get configs from '['PROJECT', 'CONFIGJS']' section(s)

from org.transcrypt.stubs.browser import __pragma__
__pragma__('jsiter')

CONFIG = {
  "PROJECT": {
    "name": "PhanterPwaFull",
    "title": "PhanterPWA",
    "version": "0.0.1",
    "author": "PhanterJR<phanterjr@conexaodidata.com.br>",
    "debug": True
  },
  "CONFIGJS": {
    "api_server_address": "http://127.0.0.1:5000"
  }
}
__pragma__('nojsiter')
