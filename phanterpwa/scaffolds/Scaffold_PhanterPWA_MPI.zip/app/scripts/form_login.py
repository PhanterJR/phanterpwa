import phanterpwa
import cmp_auth_user

from org.transcrypt.stubs.browser import __pragma__
__pragma__('alias', "jQuery", "$")
__pragma__('skip')
jQuery = this = M = __new__ = FormData = js_undefined = localStorage = sessionStorage = JSON = 0
__pragma__('noskip')

SPAN = phanterpwa.XmlConstructor.tagger("span")


def start():
    phanterpwa.captcha(
        "#user_login",
        "#phanterpwa-input-csrf_token",
        "#phanterpwa-form-captcha-ajax-container-user_login")

    def onSubmit():
        jQuery("#user_login .phanterpwa-materialize-input-error").removeClass('enabled').text("")

        def onComplete(data, ajax_status):
            if ajax_status == "success":
                json = data.responseJSON
                authorization = json.authorization
                auth_user = json.auth_user
                client_token = json.client_token
                if (authorization is not js_undefined) and\
                        (auth_user is not js_undefined) and (client_token is not js_undefined):
                    localStorage.setItem('Client-token', client_token)
                    sessionStorage.setItem("Authorization", authorization)
                    sessionStorage.setItem("auth_user", JSON.stringify(auth_user))
                message = SPAN("Account created successfully!").jquery().phanterpwaTranslate(
                    'pt-BR',
                    "<span>Bem Vindo!</span>"
                )
                jQuery('#modal_user_login').modal("close")
                cmp_auth_user.start()
                M.toast({'html': message[0]})
            else:
                if data.status == 400:
                    message = SPAN("Please, check your form.").jquery().phanterpwaTranslate(
                        'pt-BR',
                        SPAN("Por favor, cheque seu formulário.").xml()
                    )
                    M.toast({'html': message[0]})
                    phanterpwa.captcha(
                        "#user_login",
                        "#phanterpwa-input-csrf_token",
                        "#phanterpwa-form-captcha-ajax-container-user_login")
                    json = data.responseJSON
                    errors = dict(json['errors'])
                    if errors is not js_undefined:
                        for x in errors.keys():
                            id_error = "#phanterpwa-materialize-input-error-" + x
                            message = SPAN(errors[x]).xml()
                            jQuery(id_error).html(message).addClass("enabled")
        formdata = __new__(FormData())
        formdata.append(jQuery("#phanterpwa-input-csrf_token").attr("name"), jQuery("#phanterpwa-input-csrf_token").val())
        login_password = window.btoa(jQuery("#phanterpwa-input-email").val()) + ":" + window.btoa(jQuery("#phanterpwa-input-password").val())
        formdata.append("edata", login_password)
        url = phanterpwa.API_SERVER_ADDRESS + "/api/auth/"
        phanterpwa.POST(url, formdata, onComplete)
    jQuery("#user_login").phanterpwaLanguage().phanterpwaFormValidator()
    jQuery(
        "#user_login-ajax-button-submit"
    ).off(
        "click.user_login_submit"
    ).on(
        "click.user_login_submit",
        onSubmit
    )
