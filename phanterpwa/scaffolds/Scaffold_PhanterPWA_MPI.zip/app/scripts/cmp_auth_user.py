import form_login
import form_register
import form_request_password
import phanterpwa
from org.transcrypt.stubs.browser import __pragma__
__pragma__('alias', "jQuery", "$")
__pragma__('skip')
jQuery = sessionStorage = JSON = js_undefined = 0
__pragma__('noskip')


def start():
    authorization = sessionStorage.getItem("Authorization")

    def switch_menu_login():
        if jQuery(".cmp-bar_user_and_menu-container").hasClass("enabled"):
            jQuery("#phanterpwa-component-left_bar-user").removeClass("enabled")
            jQuery("#left_bar, #menu-button-main-page").removeClass("enabled_submenu")
            jQuery(".cmp-bar_user_and_menu-container").removeClass("enabled")

        else:
            jQuery(".cmp-bar_user_and_menu-container").addClass("enabled")
            jQuery("#phanterpwa-component-left_bar-user").addClass("enabled")
            jQuery("#left_bar, #menu-button-main-page").addClass("enabled_submenu")

    def on_modal_login_load(data):
        jQuery("#user_login").phanterpwaLanguage()
        __pragma__('jsiter')
        modal_cfg = {'onOpenEnd': lambda: form_login.start()}
        __pragma__('nojsiter')
        jQuery('#modal_user_login').modal(modal_cfg).modal("open")

        jQuery(
            "#modal_user_login .phanterpwa-models-close"
        ).off(
            "click.phanterpwa-models-close"
        ).on(
            "click.phanterpwa-models-close",
            lambda: jQuery('#modal_user_login').modal("close")
        )
        jQuery(
            "#user_login-ajax-button-register"
        ).off(
            "click.user_login-ajax-button-register"
        ).on(
            "click.user_login-ajax-button-register", on_register_click
        )
        jQuery(
            "#user_login-ajax-button-request_password"
        ).off(
            "click.user_login-ajax-button-request_password"
        ).on(
            "click.user_login-ajax-button-request_password", on_request_password_click
        )

    def on_modal_register_load(data):
        jQuery("#user_register").phanterpwaLanguage()
        __pragma__('jsiter')
        modal_cfg = {'onOpenEnd': lambda: form_register.start()}
        __pragma__('nojsiter')
        jQuery('#modal_user_register').modal(modal_cfg).modal("open")

        jQuery(
            "#modal_user_register .phanterpwa-models-close"
        ).off(
            "click.phanterpwa-models-close"
        ).on(
            "click.phanterpwa-models-close",
            lambda: jQuery('#modal_user_register').modal("close")
        )
        jQuery(
            "#user_register-ajax-button-login"
        ).off(
            "click.user_register-ajax-button-login"
        ).on(
            "click.user_register-ajax-button-login", on_login_click
        )
        jQuery(
            "#user_register-ajax-button-request_password"
        ).off(
            "click.user_register-ajax-button-request_password"
        ).on(
            "click.user_register-ajax-button-request_password", on_request_password_click
        )

    def on_modal_request_password_load(data):
        jQuery("#user_request_password").phanterpwaLanguage()
        __pragma__('jsiter')
        modal_cfg = {'onOpenEnd': lambda: form_request_password.start()}
        __pragma__('nojsiter')
        jQuery('#modal_user_request_password').modal(modal_cfg).modal("open")

        jQuery(
            "#modal_user_request_password .phanterpwa-models-close"
        ).off(
            "click.phanterpwa-models-close"
        ).on(
            "click.phanterpwa-models-close",
            lambda: jQuery('#modal_user_request_password').modal("close")
        )
        jQuery(
            "#user_request_password-ajax-button-login"
        ).off(
            "click.user_request_password-ajax-button-login"
        ).on(
            "click.user_request_password-ajax-button-login", on_login_click
        )
        jQuery(
            "#user_request_password-ajax-button-register"
        ).off(
            "click.user_request_password-ajax-button-register"
        ).on(
            "click.user_request_password-ajax-button-register", on_register_click
        )

    def on_login_click():
        jQuery(".modal").modal("close")
        jQuery(".cmp-bar_user_and_menu-container").removeClass("enabled")
        jQuery("#phanterpwa-component-left_bar-user").removeClass("enabled")
        jQuery("#left_bar").removeClass("enabled_submenu")
        jQuery("#modal-container").load("./extends/modal_login.html", on_modal_login_load)

    def on_register_click():
        jQuery(".modal").modal("close")
        jQuery(".cmp-bar_user_and_menu-container").removeClass("enabled")
        jQuery("#phanterpwa-component-left_bar-user").removeClass("enabled")
        jQuery("#left_bar").removeClass("enabled_submenu")
        jQuery("#modal-container").load("./extends/modal_register.html", on_modal_register_load)

    def on_request_password_click():
        jQuery(".modal").modal("close")
        jQuery(".cmp-bar_user_and_menu-container").removeClass("enabled")
        jQuery("#phanterpwa-component-left_bar-user").removeClass("enabled")
        jQuery("#left_bar").removeClass("enabled_submenu")
        jQuery("#modal-container").load("./extends/modal_request_password.html", on_modal_request_password_load)

    def on_logout_click():
        jQuery(".modal").modal("close")
        jQuery(".cmp-bar_user_and_menu-container").removeClass("enabled")
        jQuery("#phanterpwa-component-left_bar-user").removeClass("enabled")
        jQuery("#left_bar").removeClass("enabled_submenu")
        sessionStorage.removeItem("auth_user")
        sessionStorage.removeItem("Authorization")
        start()

    def bind_login():
        jQuery(
            "#cmp-bar_usermenu-option-login, #phanterpwa-component-left_bar-submenu-button-login"
        ).off(
            "click.cmp-bar_usermenu-option-login"
        ).on(
            "click.cmp-bar_usermenu-option-login", on_login_click
        )

    def bind_register():
        jQuery(
            "#cmp-bar_usermenu-option-register, #phanterpwa-component-left_bar-submenu-button-register"
        ).off(
            "click.cmp-bar_usermenu-option-register"
        ).on(
            "click.cmp-bar_usermenu-option-register", on_register_click
        )

    def bind_request_password():
        jQuery(
            "#cmp-bar_usermenu-option-request_password, #phanterpwa-component-left_bar-submenu-button-request_password"
        ).off(
            "click.cmp-bar_usermenu-option-request_password"
        ).on(
            "click.cmp-bar_usermenu-option-request_password", on_request_password_click
        )

    def bind_logout():
        jQuery(
            "#cmp-bar_usermenu-option-logout, #phanterpwa-component-left_bar-submenu-button-logout"
        ).off(
            "click.cmp-bar_usermenu-option-logout"
        ).on(
            "click.cmp-bar_usermenu-option-logout", on_logout_click
        )

    def bind_menu_click():
        jQuery("#user_login_and_menu-container").phanterpwaLanguage()
        jQuery("#phanterpwa-component-left_bar-user").phanterpwaLanguage()
        jQuery(
            "#toggle-cmp-bar_user, #phanterpwa-component-left_bar-user .phanterpwa-component-left_bar-menu"
        ).off(
            "click.cmp_user_login"
        ).on(
            "click.cmp_user_login", switch_menu_login
        )

    def binds_nologin():
        phanterpwa.route_links()
        bind_menu_click()
        bind_register()
        bind_login()
        bind_request_password()

    def binds_login():
        phanterpwa.route_links()
        bind_menu_click()
        auth_user = sessionStorage.getItem("auth_user")
        if (auth_user is not None) and (auth_user is not "undefined"):
            auth_user = JSON.parse(auth_user)
            jQuery(
                "#user_first_and_last_name_login, #phanterpwa-component-left_bar-name-user"
            ).text(
                auth_user['first_name'] + " " + auth_user['last_name']
            )
            jQuery("#user_role_login").text(auth_user['role'])
        bind_logout()
    if (authorization is None) or (authorization is js_undefined) or (authorization == "undefined"):
        sessionStorage.removeItem("auth_user")
        sessionStorage.removeItem("Authorization")
        jQuery("#user_login_and_menu-container").load("./extends/component_user_nologin.html", binds_nologin)
        jQuery("#options-top-main-bar-left").load("./extends/component_user_nologin_menu.html", binds_nologin)
    else:
        jQuery("#user_login_and_menu-container").load("./extends/component_user_login.html", binds_login)
        jQuery("#options-top-main-bar-left").load("./extends/component_user_login_menu.html", binds_login)
