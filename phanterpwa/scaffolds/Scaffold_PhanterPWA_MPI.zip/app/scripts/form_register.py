import phanterpwa
import cmp_auth_user

from org.transcrypt.stubs.browser import __pragma__
__pragma__('alias', "jQuery", "$")
__pragma__('skip')
jQuery = this = M = __new__ = FormData = js_undefined = localStorage = sessionStorage = JSON = 0
__pragma__('noskip')

SPAN = phanterpwa.XmlConstructor.tagger("span")


def start():
    phanterpwa.captcha(
        "#user_register",
        "#phanterpwa-input-csrf_token",
        "#phanterpwa-form-captcha-ajax-container-user_register")

    def onSubmit():
        jQuery("#user_register .phanterpwa-materialize-input-error").removeClass('enabled').text("")

        def onComplete(data, ajax_status):
            if ajax_status == "success":
                json = data.responseJSON
                authorization = json.authorization
                auth_user = json.auth_user
                client_token = json.client_token
                if (authorization is not js_undefined) and\
                        (auth_user is not js_undefined) and (client_token is not js_undefined):
                    localStorage.setItem('Client-token', client_token)
                    sessionStorage.setItem("Authorization", authorization)
                    sessionStorage.setItem("auth_user", JSON.stringify(auth_user))
                message = SPAN("Account created successfully!").jquery().phanterpwaTranslate(
                    'pt-BR',
                    "<span>Conta criada com sucesso!</span>"
                )
                jQuery('#modal_user_register').modal("close")
                cmp_auth_user.start()
                M.toast({'html': message[0]})
            else:
                if data.status == 400:
                    message = SPAN("Please, check your form.").jquery().phanterpwaTranslate(
                        'pt-BR',
                        SPAN("Por favor, cheque seu formulário.").xml()
                    )
                    M.toast({'html': message[0]})
                    phanterpwa.captcha(
                        "#user_register",
                        "#phanterpwa-input-csrf_token",
                        "#phanterpwa-form-captcha-ajax-container-user_register")
                    json = data.responseJSON
                    errors = dict(json['errors'])
                    if errors is not js_undefined:
                        for x in errors.keys():
                            id_error = "#phanterpwa-materialize-input-error-" + x
                            message = SPAN(errors[x]).xml()
                            jQuery(id_error).html(message).addClass("enabled")

            print('form send')
        formdata = __new__(FormData(jQuery("#user_register")[0]))
        url = phanterpwa.API_SERVER_ADDRESS + "/api/auth/create/"
        phanterpwa.POST(url, formdata, onComplete)

    jQuery("#user_register").phanterpwaLanguage().phanterpwaFormValidator()
    jQuery(
        "#user_register-ajax-button-submit"
    ).off(
        "click.user_register_submit"
    ).on(
        "click.user_register_submit",
        onSubmit
    )
