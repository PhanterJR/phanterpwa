// Transcrypt'ed from Python, 2019-06-20 21:46:54
var config = {};
var routes = {};
import {AssertionError, AttributeError, BaseException, DeprecationWarning, Exception, IndexError, IterableError, KeyError, NotImplementedError, RuntimeWarning, StopIteration, UserWarning, ValueError, Warning, __JsIterator__, __PyIterator__, __Terminal__, __add__, __and__, __call__, __class__, __envir__, __eq__, __floordiv__, __ge__, __get__, __getcm__, __getitem__, __getslice__, __getsm__, __gt__, __i__, __iadd__, __iand__, __idiv__, __ijsmod__, __ilshift__, __imatmul__, __imod__, __imul__, __in__, __init__, __ior__, __ipow__, __irshift__, __isub__, __ixor__, __jsUsePyNext__, __jsmod__, __k__, __kwargtrans__, __le__, __lshift__, __lt__, __matmul__, __mergefields__, __mergekwargtrans__, __mod__, __mul__, __ne__, __neg__, __nest__, __or__, __pow__, __pragma__, __proxy__, __pyUseJsNext__, __rshift__, __setitem__, __setproperty__, __setslice__, __sort__, __specialattrib__, __sub__, __super__, __t__, __terminal__, __truediv__, __withblock__, __xor__, abs, all, any, assert, bool, bytearray, bytes, callable, chr, copy, deepcopy, delattr, dict, dir, divmod, enumerate, filter, float, getattr, hasattr, input, int, isinstance, issubclass, len, list, map, max, min, object, ord, pow, print, property, py_TypeError, py_iter, py_metatype, py_next, py_reversed, py_typeof, range, repr, round, set, setattr, sorted, str, sum, tuple, zip} from './org.transcrypt.__runtime__.js';
import * as __module_routes__ from './routes.js';
__nest__ (routes, '', __module_routes__);
import * as __module_config__ from './config.js';
__nest__ (config, '', __module_config__);
var __name__ = 'phanterpwa';
export var XmlConstructor =  __class__ ('XmlConstructor', [object], {
	__module__: __name__,
	get __init__ () {return __get__ (this, function (self, tag, singleton) {
		var attributes = dict ();
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
						case 'tag': var tag = __allkwargs0__ [__attrib0__]; break;
						case 'singleton': var singleton = __allkwargs0__ [__attrib0__]; break;
						default: attributes [__attrib0__] = __allkwargs0__ [__attrib0__];
					}
				}
				delete attributes.__kwargtrans__;
			}
			var content = tuple ([].slice.apply (arguments).slice (3, __ilastarg0__ + 1));
		}
		else {
			var content = tuple ();
		}
		self.tag = tag;
		self.singleton = singleton;
		self.content = content;
		self.attributes = attributes;
	});},
	get _get_tag () {return __get__ (this, function (self) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		return self._tag;
	});},
	get _set_tag () {return __get__ (this, function (self, tag) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
						case 'tag': var tag = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		self._tag = tag;
	});},
	get _get_singleton () {return __get__ (this, function (self) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		return self._singleton;
	});},
	get _set_singleton () {return __get__ (this, function (self, singleton) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
						case 'singleton': var singleton = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		if (isinstance (singleton, bool)) {
			self._singleton = singleton;
		}
		else {
			var __except0__ = py_TypeError ('The singleton must be bool, given: {0}'.format (str (singleton)));
			__except0__.__cause__ = null;
			throw __except0__;
		}
	});},
	get xml () {return __get__ (this, function (self) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		if (self.singleton === true) {
			self.el = $ ('<{0}>'.format (self.tag));
		}
		else {
			self.el = $ ('<{0}></{0}>'.format (str (self.tag)));
			for (var c of self.content) {
				if (isinstance (c, str)) {
					self.el.append ($ ('<div/>').text (c).html ());
				}
				else if (isinstance (c, XmlConstructor)) {
					self.el.append (c.jquery ());
				}
				else {
					self.el.append (c);
				}
			}
		}
		for (var t of self.attributes.py_keys ()) {
			if (t.startswith ('_')) {
				self.el.attr (t.__getslice__ (1, null, 1), self.attributes [t]);
			}
		}
		return self.el [0].outerHTML;
	});},
	get __str__ () {return __get__ (this, function (self) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		return self.xml ();
	});},
	get jquery () {return __get__ (this, function (self) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		self.xml ();
		return self.el;
	});},
	get tagger () {return function (tag, singleton) {
		if (typeof singleton == 'undefined' || (singleton != null && singleton.hasOwnProperty ("__kwargtrans__"))) {;
			var singleton = false;
		};
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'tag': var tag = __allkwargs0__ [__attrib0__]; break;
						case 'singleton': var singleton = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		return (function __lambda__ () {
			var attributes = dict ();
			if (arguments.length) {
				var __ilastarg0__ = arguments.length - 1;
				if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
					var __allkwargs0__ = arguments [__ilastarg0__--];
					for (var __attrib0__ in __allkwargs0__) {
						switch (__attrib0__) {
							default: attributes [__attrib0__] = __allkwargs0__ [__attrib0__];
						}
					}
					delete attributes.__kwargtrans__;
				}
				var content = tuple ([].slice.apply (arguments).slice (0, __ilastarg0__ + 1));
			}
			else {
				var content = tuple ();
			}
			return XmlConstructor (tag, singleton, ...content, __kwargtrans__ (attributes));
		});
	};}
});
Object.defineProperty (XmlConstructor, 'singleton', property.call (XmlConstructor, XmlConstructor._get_singleton, XmlConstructor._set_singleton));
Object.defineProperty (XmlConstructor, 'tag', property.call (XmlConstructor, XmlConstructor._get_tag, XmlConstructor._set_tag));;
export var XML =  __class__ ('XML', [XmlConstructor], {
	__module__: __name__,
	get __init__ () {return __get__ (this, function (self) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
			var content = tuple ([].slice.apply (arguments).slice (1, __ilastarg0__ + 1));
		}
		else {
			var content = tuple ();
		}
		XmlConstructor.__init__ (self, '', false, ...content);
	});},
	get xml () {return __get__ (this, function (self) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		var html = '';
		for (var c of self.content) {
			if (isinstance (c, str)) {
				html += c;
			}
			else if (isinstance (c, XmlConstructor)) {
				html += c.xml ();
			}
			else {
				html += c;
			}
		}
		return html;
	});},
	get jquery () {return __get__ (this, function (self) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		var html = self.xml ();
		return html;
	});}
});
export var CONCATENATE =  __class__ ('CONCATENATE', [XmlConstructor], {
	__module__: __name__,
	get __init__ () {return __get__ (this, function (self) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
			var content = tuple ([].slice.apply (arguments).slice (1, __ilastarg0__ + 1));
		}
		else {
			var content = tuple ();
		}
		XmlConstructor.__init__ (self, '', false, ...content);
	});},
	get xml () {return __get__ (this, function (self) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		var html = '';
		for (var c of self.content) {
			if (isinstance (c, str)) {
				html += $ ('<div/>').text (c).html ();
			}
			else if (isinstance (c, XmlConstructor)) {
				html += c.xml ();
			}
			else {
				html += c;
			}
		}
		return html;
	});},
	get jquery () {return __get__ (this, function (self) {
		if (arguments.length) {
			var __ilastarg0__ = arguments.length - 1;
			if (arguments [__ilastarg0__] && arguments [__ilastarg0__].hasOwnProperty ("__kwargtrans__")) {
				var __allkwargs0__ = arguments [__ilastarg0__--];
				for (var __attrib0__ in __allkwargs0__) {
					switch (__attrib0__) {
						case 'self': var self = __allkwargs0__ [__attrib0__]; break;
					}
				}
			}
		}
		else {
		}
		var html = self.xml ();
		return html;
	});}
});
export var remoteAjaxList = set ();
export var API_SERVER_ADDRESS = config.CONFIG ['CONFIGJS'] ['api_server_address'];
export var addEventProgressBar = function (event_name) {
	var progress_bar = $ ('#main-progress-bar');
	var events = progress_bar.attr ('events');
	if (events === undefined) {
		progress_bar.attr ('events', JSON.stringify ([event_name]));
	}
	else {
		var events = set (JSON.parse (events));
		events.add (event_name);
		var events = list (events);
		progress_bar.attr ('events', JSON.stringify (events));
	}
};
export var removeEventProgressBar = function (event_name) {
	var progress_bar = $ ('#main-progress-bar');
	var events = progress_bar.attr ('events');
	if (events !== undefined) {
		var events = set (JSON.parse (events));
		events.remove (event_name);
		var events = JSON.stringify (list (events));
		if (events != '[]') {
			progress_bar.attr ('events', events);
		}
		else {
			progress_bar.removeAttr ('events');
		}
	}
};
export var start_progressbar = function () {
	var check_progressbar = function () {
		var progress_bar = $ ('#main-progress-bar');
		var events = progress_bar.attr ('events');
		if (events !== undefined) {
			progress_bar.addClass ('enabled');
		}
		else {
			progress_bar.removeClass ('enabled');
		}
	};
	window.setInterval (check_progressbar, 1000);
};
export var getClientToken = function (callback) {
	if (typeof callback == 'undefined' || (callback != null && callback.hasOwnProperty ("__kwargtrans__"))) {;
		var callback = null;
	};
	addEventProgressBar ('getClientToken');
	var onComplete = function (data, ajax_status) {
		print ('eitcha');
		removeEventProgressBar ('getClientToken');
		if (ajax_status == 'success') {
			var auth_user = data.responseJSON.auth_user;
			if (auth_user == 'anonymous' || auth_user == 'logout') {
				sessionStorage.removeItem ('Authorization');
				sessionStorage.removeItem ('auth_user');
				if (callback !== null) {
					print ('callback');
					callback ();
				}
			}
			var c_token = data.responseJSON.client_token;
			if (c_token !== undefined) {
				localStorage.setItem ('Client-token', c_token);
			}
		}
		else if (data.status == 0) {
			print ('Sem resposta do servidor');
		}
		else if (data.status == 400) {
			localStorage.removeItem ('Client-token');
			sessionStorage.removeItem ('Authorization');
			sessionStorage.removeItem ('auth_user');
		}
	};
	var client_token = localStorage.getItem ('Client-token');
	var authorization = sessionStorage.getItem ('Authorization');
	var url = API_SERVER_ADDRESS + '/api/client/';
	var ajax_param = {'url': url, 'type': 'GET', 'crossOrigin': true, 'complete': onComplete, 'datatype': 'json', 'headers': {'Cache-Control': 'no-store, must-revalidate, no-cache, max-age=0', 'Application': config.CONFIG ['PROJECT'] ['name'], 'Application-version': config.CONFIG ['PROJECT'] ['version']}};
	if (client_token !== null) {
		ajax_param ['headers'] ['Client-token'] = client_token;
	}
	else {
		sessionStorage.removeItem ('Authorization');
		sessionStorage.removeItem ('auth_user');
	}
	if (authorization !== null) {
		ajax_param ['headers'] ['Authorization'] = authorization;
	}
	else {
		sessionStorage.removeItem ('Authorization');
		sessionStorage.removeItem ('auth_user');
	}
	remoteAjaxList.add ('getClientToken');
	return $.ajax (ajax_param);
};
export var getSignForm = function (identify_form, onComplete) {
	addEventProgressBar ('getSignForm');
	var client_token = localStorage.getItem ('Client-token');
	var authorization = sessionStorage.getItem ('Authorization');
	var identify_form = identify_form;
	var url = (API_SERVER_ADDRESS + '/api/signforms/') + identify_form;
	var ajax_param = {'url': url, 'type': 'GET', 'crossOrigin': true, 'complete': onComplete, 'success': (function __lambda__ () {
		return removeEventProgressBar ('getSignForm');
	}), 'error': (function __lambda__ () {
		return removeEventProgressBar ('getSignForm');
	}), 'datatype': 'json', 'headers': {'Cache-Control': 'no-store, must-revalidate, no-cache, max-age=0', 'Application': config.CONFIG ['PROJECT'] ['name'], 'Application-version': config.CONFIG ['PROJECT'] ['version']}};
	if (client_token !== null) {
		ajax_param ['headers'] ['Client-token'] = client_token;
	}
	if (authorization !== null) {
		ajax_param ['headers'] ['Authorization'] = authorization;
	}
	$.ajax (ajax_param);
};
export var postSignForm = function (form, onComplete) {
	addEventProgressBar ('postSignForm');
	var client_token = localStorage.getItem ('Client-token');
	var authorization = sessionStorage.getItem ('Authorization');
	var url = (API_SERVER_ADDRESS + '/api/signforms/') + form ['id_form'];
	var ajax_param = {'url': url, 'type': 'POST', 'data': form, 'complete': onComplete, 'success': (function __lambda__ () {
		return removeEventProgressBar ('postSignForm');
	}), 'error': (function __lambda__ () {
		return removeEventProgressBar ('postSignForm');
	}), 'datatype': 'json', 'headers': {'Cache-Control': 'no-store, must-revalidate, no-cache, max-age=0', 'Application': config.CONFIG ['PROJECT'] ['name'], 'Application-version': config.CONFIG ['PROJECT'] ['version']}};
	if (client_token !== null) {
		ajax_param ['headers'] ['Client-token'] = client_token;
	}
	if (authorization !== null) {
		ajax_param ['headers'] ['Authorization'] = authorization;
	}
	$.ajax (ajax_param);
};
export var POST = function (url, form, onComplete) {
	var date_stamp = new Date ().getTime ();
	addEventProgressBar ('POST_' + date_stamp);
	var client_token = localStorage.getItem ('Client-token');
	var authorization = sessionStorage.getItem ('Authorization');
	var ajax_param = {'url': url, 'type': 'POST', 'data': form, 'complete': onComplete, 'success': (function __lambda__ () {
		return removeEventProgressBar ('POST_' + date_stamp);
	}), 'error': (function __lambda__ () {
		return removeEventProgressBar ('POST_' + date_stamp);
	}), 'datatype': 'json', 'crossDomain': true, 'headers': {'Cache-Control': 'no-store, must-revalidate, no-cache, max-age=0', 'Application': config.CONFIG ['PROJECT'] ['name'], 'Application-version': config.CONFIG ['PROJECT'] ['version']}};
	if (client_token !== null) {
		ajax_param ['headers'] ['Client-token'] = client_token;
	}
	if (authorization !== null) {
		ajax_param ['headers'] ['Authorization'] = authorization;
	}
	var ISTYPEOF = form instanceof FormData
	if (ISTYPEOF) {
		ajax_param ['processData'] = false;
		ajax_param ['contentType'] = false;
	}
	$.ajax (ajax_param);
};
export var route_links = function () {
	var route_link = function (el) {
		var ro = $ (el).attr ('phanterpwa_route');
		$ (el).off ('click.route').on ('click.route', (function __lambda__ () {
			return route (ro);
		}));
	};
	$ ('[phanterpwa_route]').each ((function __lambda__ () {
		return route_link (this);
	}));
};
export var route = function (r) {
	console.log (routes.routes);
	console.log (r);
	route_links ();
	if (__in__ (r, routes.routes)) {
		routes.routes [r] ();
	}
	else {
		console.log (("roteamento de '" + r) + "' falhou!");
	}
};
export var captcha = function (id_form_container, id_input_csrf, id_captcha_container) {
	var id_form = id_form_container.__getslice__ (1, null, 1);
	$ ('#phanterpwa-input-csrf_token').val ('').trigger ('keyup');
	var reloadCaptcha = function (id_captcha_container, html, signature) {
		$ (id_captcha_container).html (html).phanterpwaLanguage ();
		$ ('.captcha-option').off ('click.captcha-option' + id_captcha_container.__getslice__ (1, null, 1)).on ('click.captcha-option' + id_captcha_container.__getslice__ (1, null, 1), (function __lambda__ () {
			return actionClickCaptchaOption (this, signature);
		}));
	};
	var onCaptchaFailConection = function (id_captcha_container, id_form) {
		var callbackLoad = function () {
			$ (id_captcha_container + ' #captcha_reload_conection_fail_messagem').phanterpwaTranslate ('pt-BR', 'A Conexão Falhou!');
			$ (id_captcha_container + ' #captcha_reload_conection_try_again_messagem').phanterpwaTranslate ('pt-BR', 'Tente novamente');
			var button = $ (id_captcha_container + ' .captcha_reload_conection_button');
			button.off ('click.captcha_reload_conection_button' + id_captcha_container.__getslice__ (1, null, 1)).on ('click.captcha_reload_conection_button' + id_captcha_container.__getslice__ (1, null, 1), (function __lambda__ () {
				return $ (id_captcha_container).load ('/components/preloader_circle_big.html', (function __lambda__ () {
					return getSignForm (id_form, getSignFormOnComplete);
				}));
			}));
		};
		$ (id_captcha_container).load ('/components/captcha_reload.html', callbackLoad);
	};
	var getSignFormOnComplete = function (data, ajax_status) {
		if (ajax_status == 'success') {
			if (data.responseJSON.status == 'OK') {
				var signature = data.responseJSON.signature;
				var html = data.responseJSON.captcha;
				reloadCaptcha (id_captcha_container, html, signature);
			}
		}
		else if (data.status == 0) {
			onCaptchaFailConection (id_captcha_container, id_form);
		}
	};
	var actionClickCaptchaOption = function (el, signature) {
		var user_choice = $ (el).attr ('token_option');
		var signature = signature;
		var id_form = $ (el).attr ('id_captcha');
		var form = {'user_choice': user_choice, 'signature': signature, 'id_form': id_form};
		var postSignFormOnComplete = function (data, ajax_status) {
			if (ajax_status == 'success') {
				var html = data.responseJSON.captcha;
				var csrf = data.responseJSON.csrf;
				$ (id_input_csrf).val (csrf);
				$ (id_captcha_container).html (html);
				$ (id_form_container).trigger ('keyup');
			}
			else {
				if (data.status == 0) {
					onCaptchaFailConection (id_captcha_container, id_form);
				}
				else {
					var signature = data.responseJSON.signature;
					var html = data.responseJSON.captcha;
					reloadCaptcha (id_captcha_container, html, signature);
				}
				$ (id_input_csrf).val ('');
				$ (id_form_container).trigger ('keyup');
			}
		};
		$ (id_captcha_container).load ('/components/preloader_circle_big.html', (function __lambda__ () {
			return postSignForm (form, postSignFormOnComplete);
		}));
	};
	$ (id_captcha_container).load ('/components/preloader_circle_big.html', (function __lambda__ () {
		return getSignForm (id_form, getSignFormOnComplete);
	}));
};
export var translate = function (jQuery_el, browser_lang, new_el_source) {
	var userLang = navigator.language || navigator.userLanguage;
	if (browser_lang == userLang) {
		jQuery_el.html (new_el_source);
	}
	return jQuery_el;
};
export var translate_phanterpwalanguage = function (jQuery_el) {
	var userLang = navigator.language || navigator.userLanguage;
	var eachElement = function (el) {
		var langs = dict (JSON.parse ($ (el).attr ('phanterpwa_languages')));
		var content = $ (el).text ();
		var content = content.strip ();
		if (__in__ (userLang, langs)) {
			if (__in__ (content, langs [userLang])) {
				$ (el).text (langs [userLang] [content]);
			}
		}
	};
	$ (jQuery_el).find ('[phanterpwa_languages]').each ((function __lambda__ () {
		return eachElement (this);
	}));
	return jQuery_el;
};
export var validateForm = function (el_form) {
	var onChange = function (el_form) {
		var id_form = el_form.attr ('id');
		var all_validate = list ();
		var validatephanterpwainput = function (el) {
			var validate_test_pass = list ();
			var validate_test = list (JSON.parse ($ (el).attr ('phanterpwa_form_validator')));
			var input_name = $ (el).attr ('name');
			var value_for_validate = $ (el).val ();
			for (var x of validate_test) {
				if (x == 'IS_NOT_EMPTY') {
					if (value_for_validate === undefined || value_for_validate === null || value_for_validate == '') {
						validate_test_pass.append (false);
					}
					else {
						validate_test_pass.append (true);
					}
				}
				if (x.startswith ('IS_EQUALS') && __in__ (':', x)) {
					var comp = $ (x.__getslice__ (10, null, 1)).val ();
					if (comp === value_for_validate) {
						validate_test_pass.append (true);
					}
					else {
						validate_test_pass.append (false);
					}
				}
				if (x == 'IS_EMAIL') {
					if (__in__ ('@', value_for_validate)) {
						var REGEX_BODY = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([_a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
						if (REGEX_BODY.test (value_for_validate)) {
							validate_test_pass.append (true);
						}
						else {
							validate_test_pass.append (false);
						}
					}
					else {
						validate_test_pass.append (false);
					}
				}
			}
			if (all (validate_test_pass)) {
				all_validate.append (true);
				$ ('#phanterpwa-input-check-' + input_name).removeClass ('no_pass');
			}
			else {
				$ ('#phanterpwa-input-check-' + input_name).addClass ('no_pass');
				all_validate.append (false);
			}
			if (all (all_validate)) {
				$ (('#' + id_form) + ' [phanterpwa_form_submit_button]').removeAttr ('disabled');
			}
			else {
				$ (('#' + id_form) + ' [phanterpwa_form_submit_button]').attr ('disabled', 'disabled');
			}
		};
		var el_input = $ (('#' + id_form) + ' [phanterpwa_form_validator]');
		var submit_button = $ (('#' + id_form) + ' [phanterpwa_form_submit_button]');
		submit_button.attr ('disabled', 'disabled');
		el_input.each ((function __lambda__ () {
			return validatephanterpwainput (this);
		}));
		print (all_validate);
	};
	$ (el_form).on ('change, keyup', (function __lambda__ () {
		return onChange (el_form);
	}));
	onChange (el_form);
};
$.fn.phanterpwaTranslate = (function __lambda__ (browser_lang, new_el_source) {
	return translate (this, browser_lang, new_el_source);
});
$.fn.phanterpwaLanguage = (function __lambda__ () {
	return translate_phanterpwalanguage (this);
});
$.fn.phanterpwaFormValidator = (function __lambda__ () {
	return validateForm (this);
});

//# sourceMappingURL=phanterpwa.map