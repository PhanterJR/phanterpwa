// Transcrypt'ed from Python, 2019-06-18 17:03:43
var form_login = {};
var form_register = {};
var form_request_password = {};
var phanterpwa = {};
import {AssertionError, AttributeError, BaseException, DeprecationWarning, Exception, IndexError, IterableError, KeyError, NotImplementedError, RuntimeWarning, StopIteration, UserWarning, ValueError, Warning, __JsIterator__, __PyIterator__, __Terminal__, __add__, __and__, __call__, __class__, __envir__, __eq__, __floordiv__, __ge__, __get__, __getcm__, __getitem__, __getslice__, __getsm__, __gt__, __i__, __iadd__, __iand__, __idiv__, __ijsmod__, __ilshift__, __imatmul__, __imod__, __imul__, __in__, __init__, __ior__, __ipow__, __irshift__, __isub__, __ixor__, __jsUsePyNext__, __jsmod__, __k__, __kwargtrans__, __le__, __lshift__, __lt__, __matmul__, __mergefields__, __mergekwargtrans__, __mod__, __mul__, __ne__, __neg__, __nest__, __or__, __pow__, __pragma__, __proxy__, __pyUseJsNext__, __rshift__, __setitem__, __setproperty__, __setslice__, __sort__, __specialattrib__, __sub__, __super__, __t__, __terminal__, __truediv__, __withblock__, __xor__, abs, all, any, assert, bool, bytearray, bytes, callable, chr, copy, deepcopy, delattr, dict, dir, divmod, enumerate, filter, float, getattr, hasattr, input, int, isinstance, issubclass, len, list, map, max, min, object, ord, pow, print, property, py_TypeError, py_iter, py_metatype, py_next, py_reversed, py_typeof, range, repr, round, set, setattr, sorted, str, sum, tuple, zip} from './org.transcrypt.__runtime__.js';
import * as __module_phanterpwa__ from './phanterpwa.js';
__nest__ (phanterpwa, '', __module_phanterpwa__);
import * as __module_form_request_password__ from './form_request_password.js';
__nest__ (form_request_password, '', __module_form_request_password__);
import * as __module_form_register__ from './form_register.js';
__nest__ (form_register, '', __module_form_register__);
import * as __module_form_login__ from './form_login.js';
__nest__ (form_login, '', __module_form_login__);
var __name__ = 'cmp_auth_user';
export var start = function () {
	var authorization = sessionStorage.getItem ('Authorization');
	var switch_menu_login = function () {
		if ($ ('.cmp-bar_user_and_menu-container').hasClass ('enabled')) {
			$ ('#phanterpwa-component-left_bar-user').removeClass ('enabled');
			$ ('#left_bar, #menu-button-main-page').removeClass ('enabled_submenu');
			$ ('.cmp-bar_user_and_menu-container').removeClass ('enabled');
		}
		else {
			$ ('.cmp-bar_user_and_menu-container').addClass ('enabled');
			$ ('#phanterpwa-component-left_bar-user').addClass ('enabled');
			$ ('#left_bar, #menu-button-main-page').addClass ('enabled_submenu');
		}
	};
	var on_modal_login_load = function (data) {
		$ ('#user_login').phanterpwaLanguage ();
		var modal_cfg = {'onOpenEnd': (function __lambda__ () {
			return form_login.start ();
		})};
		$ ('#modal_user_login').modal (modal_cfg).modal ('open');
		$ ('#modal_user_login .phanterpwa-models-close').off ('click.phanterpwa-models-close').on ('click.phanterpwa-models-close', (function __lambda__ () {
			return $ ('#modal_user_login').modal ('close');
		}));
		$ ('#user_login-ajax-button-register').off ('click.user_login-ajax-button-register').on ('click.user_login-ajax-button-register', on_register_click);
		$ ('#user_login-ajax-button-request_password').off ('click.user_login-ajax-button-request_password').on ('click.user_login-ajax-button-request_password', on_request_password_click);
	};
	var on_modal_register_load = function (data) {
		$ ('#user_register').phanterpwaLanguage ();
		var modal_cfg = {'onOpenEnd': (function __lambda__ () {
			return form_register.start ();
		})};
		$ ('#modal_user_register').modal (modal_cfg).modal ('open');
		$ ('#modal_user_register .phanterpwa-models-close').off ('click.phanterpwa-models-close').on ('click.phanterpwa-models-close', (function __lambda__ () {
			return $ ('#modal_user_register').modal ('close');
		}));
		$ ('#user_register-ajax-button-login').off ('click.user_register-ajax-button-login').on ('click.user_register-ajax-button-login', on_login_click);
		$ ('#user_register-ajax-button-request_password').off ('click.user_register-ajax-button-request_password').on ('click.user_register-ajax-button-request_password', on_request_password_click);
	};
	var on_modal_request_password_load = function (data) {
		$ ('#user_request_password').phanterpwaLanguage ();
		var modal_cfg = {'onOpenEnd': (function __lambda__ () {
			return form_request_password.start ();
		})};
		$ ('#modal_user_request_password').modal (modal_cfg).modal ('open');
		$ ('#modal_user_request_password .phanterpwa-models-close').off ('click.phanterpwa-models-close').on ('click.phanterpwa-models-close', (function __lambda__ () {
			return $ ('#modal_user_request_password').modal ('close');
		}));
		$ ('#user_request_password-ajax-button-login').off ('click.user_request_password-ajax-button-login').on ('click.user_request_password-ajax-button-login', on_login_click);
		$ ('#user_request_password-ajax-button-register').off ('click.user_request_password-ajax-button-register').on ('click.user_request_password-ajax-button-register', on_register_click);
	};
	var on_login_click = function () {
		$ ('.modal').modal ('close');
		$ ('.cmp-bar_user_and_menu-container').removeClass ('enabled');
		$ ('#phanterpwa-component-left_bar-user').removeClass ('enabled');
		$ ('#left_bar').removeClass ('enabled_submenu');
		$ ('#modal-container').load ('./extends/modal_login.html', on_modal_login_load);
	};
	var on_register_click = function () {
		$ ('.modal').modal ('close');
		$ ('.cmp-bar_user_and_menu-container').removeClass ('enabled');
		$ ('#phanterpwa-component-left_bar-user').removeClass ('enabled');
		$ ('#left_bar').removeClass ('enabled_submenu');
		$ ('#modal-container').load ('./extends/modal_register.html', on_modal_register_load);
	};
	var on_request_password_click = function () {
		$ ('.modal').modal ('close');
		$ ('.cmp-bar_user_and_menu-container').removeClass ('enabled');
		$ ('#phanterpwa-component-left_bar-user').removeClass ('enabled');
		$ ('#left_bar').removeClass ('enabled_submenu');
		$ ('#modal-container').load ('./extends/modal_request_password.html', on_modal_request_password_load);
	};
	var on_logout_click = function () {
		$ ('.modal').modal ('close');
		$ ('.cmp-bar_user_and_menu-container').removeClass ('enabled');
		$ ('#phanterpwa-component-left_bar-user').removeClass ('enabled');
		$ ('#left_bar').removeClass ('enabled_submenu');
		sessionStorage.removeItem ('auth_user');
		sessionStorage.removeItem ('Authorization');
		start ();
	};
	var bind_login = function () {
		$ ('#cmp-bar_usermenu-option-login, #phanterpwa-component-left_bar-submenu-button-login').off ('click.cmp-bar_usermenu-option-login').on ('click.cmp-bar_usermenu-option-login', on_login_click);
	};
	var bind_register = function () {
		$ ('#cmp-bar_usermenu-option-register, #phanterpwa-component-left_bar-submenu-button-register').off ('click.cmp-bar_usermenu-option-register').on ('click.cmp-bar_usermenu-option-register', on_register_click);
	};
	var bind_request_password = function () {
		$ ('#cmp-bar_usermenu-option-request_password, #phanterpwa-component-left_bar-submenu-button-request_password').off ('click.cmp-bar_usermenu-option-request_password').on ('click.cmp-bar_usermenu-option-request_password', on_request_password_click);
	};
	var bind_logout = function () {
		$ ('#cmp-bar_usermenu-option-logout, #phanterpwa-component-left_bar-submenu-button-logout').off ('click.cmp-bar_usermenu-option-logout').on ('click.cmp-bar_usermenu-option-logout', on_logout_click);
	};
	var bind_menu_click = function () {
		$ ('#user_login_and_menu-container').phanterpwaLanguage ();
		$ ('#phanterpwa-component-left_bar-user').phanterpwaLanguage ();
		$ ('#toggle-cmp-bar_user, #phanterpwa-component-left_bar-user .phanterpwa-component-left_bar-menu').off ('click.cmp_user_login').on ('click.cmp_user_login', switch_menu_login);
	};
	var binds_nologin = function () {
		phanterpwa.route_links ();
		bind_menu_click ();
		bind_register ();
		bind_login ();
		bind_request_password ();
	};
	var binds_login = function () {
		phanterpwa.route_links ();
		bind_menu_click ();
		var auth_user = sessionStorage.getItem ('auth_user');
		if (auth_user !== null && auth_user !== 'undefined') {
			var auth_user = JSON.parse (auth_user);
			$ ('#user_first_and_last_name_login, #phanterpwa-component-left_bar-name-user').text ((auth_user ['first_name'] + ' ') + auth_user ['last_name']);
			$ ('#user_role_login').text (auth_user ['role']);
		}
		bind_logout ();
	};
	if (authorization === null || authorization === undefined || authorization == 'undefined') {
		sessionStorage.removeItem ('auth_user');
		sessionStorage.removeItem ('Authorization');
		$ ('#user_login_and_menu-container').load ('./extends/component_user_nologin.html', binds_nologin);
		$ ('#options-top-main-bar-left').load ('./extends/component_user_nologin_menu.html', binds_nologin);
	}
	else {
		$ ('#user_login_and_menu-container').load ('./extends/component_user_login.html', binds_login);
		$ ('#options-top-main-bar-left').load ('./extends/component_user_login_menu.html', binds_login);
	}
};

//# sourceMappingURL=cmp_auth_user.map