import os
import glob
from pydal import DAL
database_path = os.path.join(os.path.dirname(__file__), '..', 'databases')
files = glob.glob(os.path.join(os.path.dirname(__file__), "*.py"))
db = DAL(
    'sqlite://storage.sqlite',
    pool_size=10,
    folder=database_path,
    # migrate_enabled=True,
    check_reserved=['all']
)
__all__ = [os.path.basename(x)[0:-3] for x in files if os.path.basename(x) != "__init__.py" and x[-3:] == ".py"]
__all__.append("db")
