from . import db
from pydal import Field
from pydal.validators import (
    IS_IN_DB,
    IS_EMPTY_OR,
    IS_DATETIME
)
from datetime import datetime

db.define_table('client',
    Field('token', 'text'),
    Field('id_user', 'reference auth_user', requires=IS_EMPTY_OR(IS_IN_DB(db, db.auth_user))),
    Field('date_created', 'datetime', default=datetime.now(), requires=IS_EMPTY_OR(IS_DATETIME())))

db.define_table('csrf',
    Field('token', 'text'),
    Field('form_identify', 'string'),
    Field('user_agent', 'string'),
    Field('ip', 'string'),
    Field('used', 'boolean', default=False),
    Field('date_created', 'datetime', default=datetime.now(), requires=IS_DATETIME()))
