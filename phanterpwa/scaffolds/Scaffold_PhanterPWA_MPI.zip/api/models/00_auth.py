from . import db
from pydal import Field
from pydal.validators import (
    IS_NOT_EMPTY,
    IS_EMAIL,
    IS_DATETIME,
    IS_IN_DB,
    IS_EMPTY_OR,
    IS_NOT_IN_DB
)
from datetime import datetime

db.define_table('auth_user',
    Field('first_name', 'string', notnull=True, requires=IS_NOT_EMPTY()),
    Field('last_name', 'string', notnull=True, requires=IS_NOT_EMPTY()),
    Field('email', 'string', notnull=True, unique=True),
    Field('remember_me', 'boolean', default=False),
    Field('password_hash', 'string', notnull=True, requires=IS_NOT_EMPTY()),
    Field('attempts_to_login', 'integer', default=0),
    Field('datetime_next_attempt_to_login', 'datetime', requires=IS_EMPTY_OR(IS_DATETIME())),
    Field('temporary_password', 'text'),  # it's used in the debug
    Field('temporary_password_hash', 'text'),
    Field('temporary_password_expire', 'datetime', requires=IS_EMPTY_OR(IS_DATETIME())),
    Field('activate_code', 'integer', default=0),
    Field('activate_attempts', 'integer', default=0),
    Field('activate_date_expire', 'datetime', requires=IS_EMPTY_OR(IS_DATETIME())),
    Field('retrieve_hash', 'string', unique=True),
    Field('permit_mult_login', 'boolean', default=True),
    Field('rest_key', 'string', unique=True),
    Field('rest_token', 'string', unique=True),
    Field('rest_date', 'datetime'),
    Field('activated', 'boolean', default=False, notnull=True))

db.auth_user.email.requires = [
    IS_EMAIL(),
    IS_NOT_IN_DB(db, db.auth_user.email, error_message="Email already in database.")
]

db.define_table('auth_group',
    Field('role', 'string'),
    Field('grade', 'integer', default=0),
    Field('description', 'text'))

db.define_table('auth_membership',
    Field('auth_user', 'reference auth_user', requires=IS_IN_DB(db, db.auth_user)),
    Field('auth_group', 'reference auth_group', requires=IS_IN_DB(db, db.auth_group)))

db.define_table('auth_activity',
    Field('auth_user', 'reference auth_user', requires=IS_IN_DB(db, db.auth_user)),
    Field('request', 'text'),
    Field('activity', 'string'),
    Field('date_activity', 'datetime', default=datetime.now()))

if db(db.auth_group).isempty():
    db._adapter.reconnect()
    db.auth_group.insert(role="root", grade=100, description="Administrator of application (Developer)")
    db.auth_group.insert(role="administrator", grade=10, description="Super user of site")
    db.auth_group.insert(role="user", grade=1, description="Default user")
    db.commit()

if db(db.auth_membership).isempty():
    db._adapter.reconnect()
    if db.auth_user[1]:
        id_role = db(db.auth_group.role == 'root').select().first()
        if id_role:
            db.auth_membership.insert(auth_user=1,
            auth_group=id_role.id)
            db.commit()
