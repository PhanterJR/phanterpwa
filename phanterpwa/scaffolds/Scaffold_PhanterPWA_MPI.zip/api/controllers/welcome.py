from .. import (
    flask_api,
    flask_app
)
from datetime import datetime
from flask_restful import Resource


class RestApi(Resource):
    """
        url: /api
    """

    def get(self):

        return {'status': 'OK',
            'message': 'Hello World'}


class RestServerInfo(Resource):

    def get(self):

        nova_data = datetime.now()
        dia = str(nova_data.day).zfill(2)
        mes = str(nova_data.month).zfill(2)
        ano = nova_data.year
        hora = str(nova_data.hour).zfill(2)
        minuto = str(nova_data.minute).zfill(2)
        return {
            'status': 'OK',
            'server_hour': "%s/%s/%s %s:%s:00" %
            (dia, mes, ano, hora, minuto),
            'application': {
                'debug': flask_app.debug,
                # 'application_version': app_version,
                # 'application_name': app_name
            }
        }


flask_api.add_resource(RestApi, '/api/')
flask_api.add_resource(RestServerInfo, '/api/server/')
