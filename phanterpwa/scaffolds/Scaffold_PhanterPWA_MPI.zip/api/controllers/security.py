from .. import (
    flask_api,
    flask_app
)
from core.config import CONFIG
from core.decorators import (
    check_application
)
from core.internationalization import (
    Translator_api as Translator
)
from phanterpwa.captchasvg.captcha import Captcha
from flask import request
from api.models import *
from flask_restful import Resource, reqparse
from itsdangerous import (
    TimedJSONWebSignatureSerializer as Serialize,
    BadSignature,
    SignatureExpired
)
from phanterpwa.xss import xssescape as E
from phanterpwa.helpers import (
    SPAN,
    XML
)
from inspect import currentframe, getframeinfo
parser = reqparse.RequestParser()
project_name = CONFIG['PROJECT']['name']

def sign_options(v):
        t = Serialize(
            flask_app.config['SECRET_KEY_USERS'],
            flask_app.config['DEFAULT_TIME_CSRF_TOKEN_EXPIRES']
        )
        sign_option = t.dumps({
            'option': v
        })
        return sign_option.decode("utf-8")

class RestSignForms(Resource):
    """
        url: '/api/authforms/<id_form>'
    """

    def get(self, **kargs):
        """
        Receive request to create and response with a token csrf or captcha
        """
        list_forms = ["user_login", "user_register", "user_request_password"]
        parser.add_argument('Client-token', location='headers')
        parser.add_argument('Application', location='headers')
        parser.add_argument('Authorization', location='headers')
        parser.add_argument('id_form')
        args = parser.parse_args()
        id_form = kargs['id_form']
        if args['Application'] == project_name:
            t = Serialize(
                flask_app.config['SECRET_KEY_USERS'],
                flask_app.config['DEFAULT_TIME_CLIENT_TOKEN_EXPIRES']
            )
            if args['Client-token']:
                db._adapter.reconnect()
                q = db(db.client.token == args['Client-token']).select().first()
                if q:
                    token_content = None
                    try:
                        token_content = t.loads(args['Client-token'])
                    except BadSignature:
                        token_content = None
                    except SignatureExpired:
                        token_content = None
                    if token_content:
                        if token_content['user_agent'] == str(request.user_agent):
                            if id_form in list_forms:
                                captcha = Captcha(
                                    id_form,
                                    sign_options=sign_options,
                                    translator=Translator
                                )
                                # for x in captcha.options:
                                #     langs = Translator.dictionaries(x)
                                #     captcha.options[x] = SPAN(x, _phanterpwa_languages=langs).xml()
                                choice = captcha.choice
                                t = Serialize(
                                    flask_app.config['SECRET_KEY_USERS'],
                                    flask_app.config['DEFAULT_TIME_CSRF_TOKEN_EXPIRES']
                                )
                                sign_captha = t.dumps({
                                    'id_form': id_form,
                                    'choice': choice
                                })
                                captcha.token = sign_captha.decode("utf-8")
                                return {
                                    "status": "OK",
                                    "code": 200,
                                    "captcha": captcha.html.xml(),
                                    "signature": sign_captha.decode("utf-8")
                                }, 200
                            else:
                                if flask_app.debug:
                                    frameinfo = getframeinfo(currentframe())
                                    return {
                                        "status": "Bad Request",
                                        "code": 400,
                                        "message": "The form can't sign",
                                        "error": {
                                            "file": "%s" % frameinfo.filename,
                                            "line": "%s" % (frameinfo.lineno + 1),
                                            "info": "The form isn't in permitted form list"
                                        }
                                    }, 400
                        else:
                            if flask_app.debug:
                                frameinfo = getframeinfo(currentframe())
                                return {
                                    "status": "Bad Request",
                                    "code": 400,
                                    "message": "The form can't sign",
                                    "error": {
                                        "file": "%s" % frameinfo.filename,
                                        "line": "%s" % (frameinfo.lineno + 1),
                                        "info": "User agente isn't equals registred. Given: %s, excpected: %s" %
                                            (str(request.user_agent), token_content['user_agent'])
                                    }
                                }, 400
                    else:
                        if flask_app.debug:
                            frameinfo = getframeinfo(currentframe())
                            return {
                                "status": "Bad Request",
                                "code": 400,
                                "message": "The form can't sign",
                                "error": {
                                    "file": "%s" % frameinfo.filename,
                                    "line": "%s" % (frameinfo.lineno + 1),
                                    "info": "The token is invalid."
                                }
                            }, 400
                else:
                    if flask_app.debug:
                        frameinfo = getframeinfo(currentframe())
                        return {
                            "status": "Bad Request",
                            "code": 400,
                            "message": "The form can't sign",
                            "error": {
                                "file": "%s" % frameinfo.filename,
                                "line": "%s" % (frameinfo.lineno + 1),
                                "info": "The token isn't in table client of database. given: %s" %
                                    args['Client-token']
                            }
                        }, 400
            else:
                if flask_app.debug:
                    frameinfo = getframeinfo(currentframe())
                    return {
                        "status": "Bad Request",
                        "code": 400,
                        "message": "The form can't sign",
                        "error": {
                            "file": "%s" % frameinfo.filename,
                            "line": "%s" % (frameinfo.lineno + 1),
                            "info": "The Client-token isn't in Headers"
                        }
                    }, 400
        return {
            "status": "Bad Request",
            "code": 400,
            "message": "The form can't sign"
        }, 400

    def post(self, **kargs):
        """
        Receive captcha user choice and response with csrf token
        """
        parser.add_argument('Client-token', location='headers')
        parser.add_argument('Application', location='headers')
        parser.add_argument('Authorization', location='headers')
        parser.add_argument('user_choice', location='form')
        parser.add_argument('signature', location='form')

        args = parser.parse_args()
        id_form = kargs['id_form']
        if args['Application'] == project_name:
            t = Serialize(
                flask_app.config['SECRET_KEY_USERS'],
                flask_app.config['DEFAULT_TIME_CLIENT_TOKEN_EXPIRES']
            )
            if args['Client-token']:
                db._adapter.reconnect()
                q = db(db.client.token == args['Client-token']).select().first()
                if q:
                    token_content = None
                    try:
                        token_content = t.loads(args['Client-token'])
                    except BadSignature:
                        token_content = None
                    except SignatureExpired:
                        token_content = None
                    if token_content:
                        if token_content['user_agent'] == str(request.user_agent):
                            choice = args['user_choice']
                            t = Serialize(
                                flask_app.config['SECRET_KEY_USERS'],
                                flask_app.config['DEFAULT_TIME_CSRF_TOKEN_EXPIRES']
                            )
                            read_signature = None
                            try:
                                read_signature = t.loads(args['signature'].encode("utf-8"))
                            except BadSignature:
                                read_signature = None
                            except SignatureExpired:
                                read_signature = None
                            if read_signature:
                                captcha = Captcha(id_form)
                                try:
                                    read_choice = t.loads(choice)
                                except BadSignature:
                                    read_choice = None
                                except SignatureExpired:
                                    read_choice = None
                                if captcha.check(read_signature['choice'], read_choice["option"]) and \
                                        id_form == read_signature['id_form']:
                                    db._adapter.reconnect()
                                    id_csrf = db.csrf.insert(
                                        form_identify=id_form,
                                        user_agent=str(token_content['user_agent']),
                                        ip=str(request.remote_addr)
                                    )
                                    if id_csrf:
                                        sign_captha = t.dumps({
                                            'id': str(id_csrf),
                                            'id_form': id_form,
                                            'user_agent': str(token_content['user_agent']),
                                            'ip': str(request.remote_addr)
                                        })
                                        q_csrf = db(db.csrf.id == id_csrf).select().first()
                                        q_csrf.update_record(token=sign_captha)
                                        db.commit()

                                    return {
                                        "status": "OK",
                                        "code": 200,
                                        "message": "Captcha resolved",
                                        "captcha": captcha.html_ok.xml(),
                                        "csrf": sign_captha.decode("utf-8"),
                                    }, 200
                                else:
                                    captcha = Captcha(id_form, sign_options=sign_options, translator=Translator)
                                    choice = captcha.choice
                                    t = Serialize(
                                        flask_app.config['SECRET_KEY_USERS'],
                                        flask_app.config['DEFAULT_TIME_CSRF_TOKEN_EXPIRES']
                                    )
                                    sign_captha = t.dumps({
                                        'id_form': id_form,
                                        'choice': choice
                                    })
                                    captcha.token = sign_captha.decode("utf-8")
                                    return {
                                        "status": "Reset Content",
                                        "message": "Incorrect captcha",
                                        "captcha": captcha.html.xml(),
                                        "signature": sign_captha.decode("utf-8"),
                                        "code": 409,
                                    }, 409
                            else:
                                captcha = Captcha(id_form, sign_options=sign_options, translator=Translator)
                                choice = captcha.choice
                                t = Serialize(
                                    flask_app.config['SECRET_KEY_USERS'],
                                    flask_app.config['DEFAULT_TIME_CSRF_TOKEN_EXPIRES']
                                )
                                sign_captha = t.dumps({
                                    'id_form': id_form,
                                    'choice': choice
                                })
                                captcha.token = sign_captha.decode("utf-8")
                                return {
                                    "status": "Request Timeout",
                                    "message": "Captcha Expired",
                                    "captcha": captcha.html.xml(),
                                    "signature": sign_captha.decode("utf-8"),
                                    "code": 408,
                                }, 408


class RestSignClient(Resource):
    """
        url: /api/client/
    """
    @check_application
    def get(self, *args, **kargs):
        parser.add_argument('Client-token', location='headers')
        parser.add_argument('Authorization', location='headers')
        parse_args = parser.parse_args()
        t_client = Serialize(
            flask_app.config['SECRET_KEY_USERS'],
            flask_app.config['DEFAULT_TIME_CLIENT_TOKEN_EXPIRES']
        )
        if 'Client-token' in parse_args and parse_args['Client-token']:
            db._adapter.reconnect()
            q = db(db.client.token == parse_args['Client-token']).select().first()
            if q:
                token_content_client = None
                try:
                    token_content_client = t_client.loads(parse_args['Client-token'])
                except BadSignature:
                    token_content_client = None
                except SignatureExpired:
                    token_content_client = None
                if token_content_client:
                    if token_content_client['user_agent'] == str(request.user_agent):
                        if 'id_user' in token_content_client:
                            if all(['Authorization' in parse_args,
                                    parse_args['Authorization']]):
                                t_user = Serialize(
                                    flask_app.config['SECRET_KEY_USERS'],
                                    flask_app.config['DEFAULT_TIME_TOKEN_EXPIRES']
                                )
                                token_content_user = None
                                try:
                                    token_content_user = t_user.loads(parse_args['Authorization'])
                                except BadSignature:
                                    token_content_user = None
                                except SignatureExpired:
                                    token_content_user = None
                                if token_content_user and 'id' in token_content_user:
                                    id_user = token_content_user['id']
                                    if int(token_content_user['id']) == int(id_user):
                                        q_user = db(db.auth_user.id == id_user).select().first()
                                        q_client = db(
                                            (db.client.id_user == id_user) &
                                            (db.client.token == parse_args['Client-token'])
                                        ).select().first()
                                        if q_user and q_client:
                                            if not q_user.permit_mult_login:
                                                db(
                                                    (db.client.id_user == id_user) &
                                                    (db.client.token != parse_args['Client-token'])
                                                ).delete()
                                            q_role = db(
                                                (db.auth_membership.auth_user == q_user.id) &
                                                (db.auth_group.id == db.auth_membership.auth_group)
                                            ).select(db.auth_group.role, orderby=db.auth_group.grade).last()
                                            db.commit()
                                            return {
                                                'status': 'OK',
                                                'code': 200,
                                                'auth_user': {
                                                    'id': q_user.id,
                                                    'first_name': E(q_user.first_name),
                                                    'last_name': E(q_user.last_name),
                                                    'email': q_user.email,
                                                    'role': q_role.role,
                                                },
                                                'client_token': parse_args['Client-token']
                                            }, 200
                            else:
                                return {
                                    'status': 'OK',
                                    'code': 200,
                                    'auth_user': 'logout',
                                    'client_token': parse_args['Client-token']
                                }, 200
                        else:
                            return {
                                'status': 'OK',
                                'code': 200,
                                'auth_user': 'anonymous',
                                'client_token': parse_args['Client-token']
                            }, 200

        content = {
            'user_agent': str(request.user_agent),
            'remote_addr': str(request.remote_addr)
        }
        token = t_client.dumps(content)
        db._adapter.reconnect()
        id_client = db.client.insert(token=token.decode('utf-8'))
        if id_client:
            db.commit()
            return {
                'status': 'OK',
                'code': 200,
                'auth_user': 'anonymous',
                'client_token': token.decode('utf-8')
            }, 200
        else:
            return {
                'status': 'Bad Request',
                'code': 400,
                'message': 'The register can\'t be created'
            }, 400


flask_api.add_resource(RestSignForms, '/api/signforms/', '/api/signforms/<id_form>')
flask_api.add_resource(RestSignClient, '/api/client/')
