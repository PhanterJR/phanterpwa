import base64
from .. import (
    flask_api,
    flask_app,
    flask_email
)
from core.decorators import (
    check_application,
    check_client_token,
    check_csrf_token,
    create_temporary_password,
    DictToPyDAL
)
from core.internationalization import (
    Translator_api as Translator
)
from flask_mail import Message
from datetime import datetime, timedelta
from werkzeug.security import (
    generate_password_hash,
    check_password_hash
)
from api.models import *
from flask import request
from flask_restful import (
    Resource,
    reqparse
)
from itsdangerous import (
    TimedJSONWebSignatureSerializer as Serialize, BadSignature, SignatureExpired
)
from pydal import Field
from pydal.validators import (
    IS_EQUAL_TO,
    IS_EMAIL
)
from phanterpwa.xss import xssescape as E
from phanterpwa.captchasvg.captcha import Captcha
from inspect import currentframe, getframeinfo
parser = reqparse.RequestParser()
T = Translator.T

def sign_options(v):
        t = Serialize(
            flask_app.config['SECRET_KEY_USERS'],
            flask_app.config['DEFAULT_TIME_CSRF_TOKEN_EXPIRES']
        )
        sign_option = t.dumps({
            'option': v
        })
        return sign_option.decode("utf-8")

class RestAuth(Resource):
    """
        url: /api/auth/
    """
    @check_client_token
    def get(self):
        return {'status': 'OK',
            'message': 'Hello World'}

    @check_application
    @check_client_token
    @check_csrf_token
    def post(self, *args, **kargs):
        parser.add_argument('edata', location='form')
        parser.add_argument('Client-token', location='headers')
        parse_args = parser.parse_args()
        if 'edata' in parse_args:
            edata = parse_args["edata"]
            email, password = edata.split(":")
            email = base64.b64decode(email).decode('utf-8')
            password = base64.b64decode(password)
            db._adapter.reconnect()
            q_user = db(db.auth_user.email == email).select().first()
            if q_user:
                if not q_user.attempts_to_login:
                    q_user.update_record(attempts_to_login=1)
                else:
                    q_user.update_record(attempts_to_login=q_user.attempts_to_login + 1)

                result = check_password_hash(
                    q_user.password_hash,
                    "password%s%s" %
                        (password.decode('utf-8'), flask_app.config['SECRET_KEY_USERS'])
                )
                if not result and datetime.now() < q_user.temporary_password_expire:
                    result = check_password_hash(
                        q_user.temporary_password_hash,
                        "password%s%s" %
                            (password.decode('utf-8'), flask_app.config['SECRET_KEY_USERS'])
                    )
                if q_user.attempts_to_login >= 5:
                    if q_user.datetime_next_attempt_to_login and\
                            datetime.now() <= q_user.datetime_next_attempt_to_login:
                        t_delta = q_user.datetime_next_attempt_to_login - datetime.now()
                        if t_delta.total_seconds() > 60:
                            l_time = "Plase wait about %s minutes" % \
                                int((t_delta.total_seconds() / 60) + 1)
                        else:
                            l_time = "Plase wait about %s seconds" % \
                                int(t_delta.total_seconds())
                        db.commit()
                        return {
                            'status': 'Bad Request',
                            'code': 400,
                            'message': l_time,
                            T('attempts_to_login'): q_user.attempts_to_login,
                            'i18n': Translator.dictionaries({
                                'message': l_time,
                                'attempts_to_login': 'attempts_to_login'
                            })
                        }, 400

                if result:

                    t = Serialize(
                        flask_app.config['SECRET_KEY_USERS'],
                        flask_app.config['DEFAULT_TIME_TOKEN_EXPIRES']
                    )
                    content = {
                        'id': str(q_user.id),
                        'email': email
                    }
                    token_user = t.dumps(content)
                    token_user = token_user.decode('utf-8')
                    q_role = db(
                        (db.auth_membership.auth_user == q_user.id) &
                        (db.auth_group.id == db.auth_membership.auth_group)
                    ).select(db.auth_group.role, orderby=db.auth_group.grade).last()
                    q_user.update_record(attempts_to_login=0)

                    r_client = db(db.client.token == parse_args['Client-token']).select().first()
                    if r_client:
                        r_client.delete_record()
                    token_client = parse_args['Client-token']
                    id_client = db.client.insert(id_user=q_user.id, date_created=datetime.now())
                    q_client = db(db.client.id == id_client).select().first()
                    t = Serialize(
                        flask_app.config['SECRET_KEY_USERS'],
                        flask_app.config['DEFAULT_TIME_CLIENT_TOKEN_EXPIRES']
                    )
                    content = {
                        'id_user': str(q_user.id),
                        'id_client': str(id_client),
                        'user_agent': str(request.user_agent),
                        'remote_addr': str(request.remote_addr)
                    }
                    token_client = t.dumps(content)
                    token_client = token_client.decode('utf-8')
                    q_client.update_record(
                        token=token_client,
                        date_created=datetime.now()
                    )
                    if not q_user.permit_mult_login:
                        r_client = db(
                            (db.client.id_user == q_user.id) &
                            (db.client.token != token_client)
                        ).select()
                        if r_client:
                            r_client = db(
                                (db.client.id_user == q_user.id) &
                                (db.client.token != token_client)
                            ).delete()
                    db.commit()
                    return {
                        'status': 'OK',
                        'code': 200,
                        'message': T('The user is logged'),
                        'authorization': token_user,
                        'client_token': token_client,
                        'auth_user': {
                            'id': str(q_user.id),
                            'first_name': E(q_user.first_name),
                            'last_name': E(q_user.last_name),
                            'email': email,
                            'role': q_role.role,
                        },
                        'i18n': Translator.dictionaries({
                            'message': 'The user is logged',
                            'role': q_role.role
                        })
                    }, 200
                else:
                    q_user.update_record(
                        datetime_next_attempt_to_login=datetime.now() +
                            timedelta(seconds=flask_app.config['DEFAULT_TIME_NEXT_ATTEMPT_TO_LOGIN'])
                    )
                    if q_user.attempts_to_login >= 5:
                        message = 'Wrong password! Plase wait %s minutes' %\
                            int(flask_app.config['DEFAULT_TIME_NEXT_ATTEMPT_TO_LOGIN'] / 60)
                        i18n = Translator.dictionaries({
                            'message': 'Wrong password! Plase wait %s minutes',
                            'attempts_to_login': 'attempts_to_login'
                        })
                        for x in i18n:
                            i18n[x]['message'] = i18n[x]['message'] %\
                                int(flask_app.config['DEFAULT_TIME_NEXT_ATTEMPT_TO_LOGIN'] / 60)
                    else:
                        message = 'Wrong password! Attempt: %s' % q_user.attempts_to_login
                        i18n = Translator.dictionaries({
                            'message': 'Wrong password! Attempt: %s',
                            'attempts_to_login': 'attempts_to_login'
                        })
                        for x in i18n:
                            i18n[x]['message'] = i18n[x]['message'] % q_user.attempts_to_login
                    db.commit()
                    return {
                        'status': 'Bad Request',
                        'code': 400,
                        'message': message,
                        'attempts_to_login': q_user.attempts_to_login,
                        'i18n': i18n
                    }, 400
            else:
                return {
                    'status': 'Unauthorized',
                    'code': 401,
                    'message': 'Invalid password or email',
                    'i18n': Translator.dictionaries({
                        'message': 'Invalid password or email',
                    })
                }, 401
        return {
            'status': 'Bad Request',
            'code': 400,
            'message': 'Invalid password or email',
            'i18n': Translator.dictionaries({
                'message': 'Invalid password or email'
            })
        }, 400

    def put(self):
        return {'status': 'OK',
            'message': 'Hello World'}


class RestCreateAccount(Resource):
    """
    post:
        create new user
    """

    def get(self):
        return {'status': 'OK',
            'message': 'Hello World'}

    @check_application
    @check_client_token
    @check_csrf_token
    def post(self, *args, **kargs):
        parser.add_argument('Client-token', location='headers')
        parse_args = parser.parse_args()
        db._adapter.reconnect()
        table = db.auth_user
        dict_vars = {x: request.form[x] for x in request.form}
        pass_hash = generate_password_hash("password%s%s" %
            (dict_vars['password'], flask_app.config['SECRET_KEY_USERS']))
        dict_vars['password_hash'] = pass_hash
        result = DictToPyDAL(
            dict_vars,
            *[table[x] for x in table.fields if x in ["first_name", "last_name", "email", "password_hash"]] + [
                Field(
                    'password',
                    'string',
                    requires=IS_EQUAL_TO(
                        request.form['password_repeat'], error_message=T("The passwords isn't equals"))),
                Field(
                    'password_repeat',
                    'string',
                    requires=IS_EQUAL_TO(
                        request.form['password'], error_message=T("The passwords isn't equals"))),
            ]
        )
        r = result.validate_and_insert(db.auth_user)
        if r and r.id:
            q_user = db(db.auth_user.id == r.id).select().first()
            if r.id == 1:
                role = "root"
                id_role = db(db.auth_group.role == 'root').select().first()
                if id_role:
                    db.auth_membership.insert(auth_user=1,
                    auth_group=id_role.id)
            else:
                role = "user"
                db.auth_membership.insert(auth_user=r.id, auth_group=3)
            t = Serialize(
                flask_app.config['SECRET_KEY_USERS'],
                flask_app.config['DEFAULT_TIME_TOKEN_EXPIRES']
            )
            content = {
                'id': str(r.id),
                'email': dict_vars['email']
            }
            token_user = t.dumps(content)
            token_user = token_user.decode('utf-8')
            token_client = parse_args['Client-token']
            id_client = db.client.update_or_insert(id_user=r.id)
            t = Serialize(
                flask_app.config['SECRET_KEY_USERS'],
                flask_app.config['DEFAULT_TIME_CLIENT_TOKEN_EXPIRES']
            )
            content = {
                'id_user': str(r.id),
                'id_client': str(id_client),
                'user_agent': str(request.user_agent),
                'remote_addr': str(request.remote_addr)
            }
            token_client = t.dumps(content)
            token_client = token_client.decode('utf-8')
            q_client = db(db.client.id == id_client).select().first()
            q_client.update_record(
                token=token_client,
                date_created=datetime.now()
            )
            r_client = db(db.client.token == parse_args['Client-token']).select().first()
            if r_client:
                r_client.delete_record()
            if not q_user.permit_mult_login:
                r_client = db(
                    (db.client.id_user == id_user) &
                    (db.client.token != parse_args['Client-token'])
                ).select()
                if r_client:
                    r_client = db(
                        (db.client.id_user == id_user) &
                        (db.client.token != parse_args['Client-token'])
                    ).remove()
            db.commit()
            return {
                'status': 'Created',
                'code': 201,
                'message': T('The user has been added'),
                'authorization': token_user,
                'client_token': token_client,
                'auth_user': {
                    'id': r.id,
                    'first_name': E(dict_vars['first_name']),
                    'last_name': E(dict_vars['last_name']),
                    'email': dict_vars['email'],
                    'role': role,
                },
                'i18n': Translator.dictionaries({
                    'message': 'The user has been added',
                    'role': role
                })
            }, 201
        else:
            i18n = {}
            message = 'The form has errors'
            for i in Translator.languages:
                i18n_errors = {}
                for x in result.errors:
                    tran = Translator.translator(result.errors[x], i)
                    i18n_errors[x] = tran
                i18n[i] = {
                    'message': Translator.translator(message, i),
                    'errors': i18n_errors
                }
            captcha = Captcha("resend", sign_options=sign_options)
            choice = captcha.choice
            t = Serialize(
                flask_app.config['SECRET_KEY_USERS'],
                flask_app.config['DEFAULT_TIME_CSRF_TOKEN_EXPIRES']
            )
            sign_captha = t.dumps({
                'id_form': "resend",
                'choice': choice
            })
            captcha.token = sign_captha.decode("utf-8")
            return {
                'status': 'Bad Request',
                'code': 400,
                'message': message,
                'errors': result.errors,
                'i18n': i18n,
                "captcha": captcha.html.xml(),
                "signature": sign_captha.decode("utf-8"),
            }, 400

    def options(self):
        return {'status': 'OK',
            'message': 'Hello World'}


class RestRequestAccount(Resource):
    """
    post:
        create new user
    """

    def get(self):
        return {'status': 'OK',
            'message': 'Hello World'}

    @check_application
    @check_client_token
    @check_csrf_token
    def post(self, *args, **kargs):
        dict_vars = {x: request.form[x] for x in request.form}
        result = DictToPyDAL(
            dict_vars,
            Field(
                'email',
                'string',
                requires=IS_EMAIL(
                    request.form['email'], error_message=T("The email isn't valid."))),
        )
        r = result.validate()
        if r:

            i18n = {}
            message = 'The form has errors'
            for i in Translator.languages:
                i18n_errors = {}
                for x in result.errors:
                    tran = Translator.translator(result.errors[x], i)
                    i18n_errors[x] = tran
                i18n[i] = {
                    'message': Translator.translator(message, i),
                    'errors': i18n_errors
                }
            captcha = Captcha("resend", sign_options=sign_options)
            choice = captcha.choice
            t = Serialize(
                flask_app.config['SECRET_KEY_USERS'],
                flask_app.config['DEFAULT_TIME_CSRF_TOKEN_EXPIRES']
            )
            sign_captha = t.dumps({
                'id_form': "resend",
                'choice': choice
            })
            captcha.token = sign_captha.decode("utf-8")
            return {
                'status': 'Bad Request',
                'code': 400,
                'message': message,
                'errors': result.errors,
                'i18n': i18n,
                "captcha": captcha.html.xml(),
                "signature": sign_captha.decode("utf-8"),
            }, 400
        else:
            db._adapter.reconnect()
            q_user = db(db.auth_user.email == request.form['email']).select().first()
            if q_user:
                new_password = create_temporary_password()
                text_email = '\tOlá %s %s, foi solicitada uma alteração' % (q_user.first_name, q_user.last_name) + \
                    ' de senha de uma conta vinculada a este email, utilize' + \
                    ' a seguinte senha para prosseguir com a alteração:' + \
                    ' %s.\nBasta acessar o site e logar com esta senha que' % (new_password) + \
                    ' foi enviada, ela estará ativa apenas 10 minutos.'
                html_email = '<h3>Olá %s %s,</h3><br /><p>foi solicitada' % (q_user.first_name, q_user.last_name) + \
                    ' uma alteração de senha de uma conta vinculada a este' + \
                    ' email, utilize a seguinte senha para prosseguir com' + \
                    ' a alteração: <b>%s</b></p><p>Basta acessar o site e' % (new_password) + \
                    ' logar com esta senha que foi enviada, ela estará' + \
                    ' ativa apenas 10 minutos.</p>'

                msg = Message(
                    "Senha temporária de recuperação",
                    sender=flask_app.config['MAIL_USERNAME']
                )
                msg.recipients = [request.form['email']]
                msg.body = text_email
                msg.html = html_email
                result = None
                try:
                    result = flask_email.send(msg)
                except Exception as e:
                    result = "Email from '%s' to '%s' don't send! -> Error: %s" %\
                        (flask_app.config['MAIL_USERNAME'], request.form['email'], e)
                pass_hash = generate_password_hash("password%s%s" %
                    (new_password, flask_app.config['SECRET_KEY_USERS']))
                if flask_app.debug:
                    q_user.update_record(
                        temporary_password=new_password,
                        temporary_password_hash=pass_hash,
                        temporary_password_expire=datetime.now() +
                            timedelta(seconds=flask_app.config['DEFAULT_TIME_TEMPORARY_PASSWORD_EXPIRES'])
                    )
                else:
                    q_user.update_record(
                        temporary_password_hash=pass_hash,
                        temporary_password_expire=datetime.now() +
                            timedelta(seconds=flask_app.config['DEFAULT_TIME_TEMPORARY_PASSWORD_EXPIRES'])
                    )
                db.commit()
                return {
                    'status': 'OK',
                    'code': 200,
                    'message': T('An email was sent instructing you how to proceed to recover your account.'),
                    'i18n': Translator.dictionaries({
                        'message': 'An email was sent instructing you how to proceed to recover your account.'
                    })
                }, 200

    def options(self):
        return {'status': 'OK',
            'message': 'Hello World'}


flask_api.add_resource(RestAuth, '/api/auth/')
flask_api.add_resource(RestCreateAccount, '/api/auth/create/')
flask_api.add_resource(RestRequestAccount, '/api/auth/request-password/')
