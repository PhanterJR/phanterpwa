import os
from flask import (Flask, request)
from flask_cors import CORS
from flask_mail import Mail
from flask_restful import (Api, reqparse)
from functools import wraps
from .models import *
from pydal import Field
from itsdangerous import (
    TimedJSONWebSignatureSerializer as Serialize, BadSignature, SignatureExpired
)
from core.config import CONFIG

flask_app = Flask(__name__)
flask_api = Api(flask_app)
flask_email = Mail(flask_app)

__author__ = CONFIG['PROJECT']['author']
__version__ = CONFIG['PROJECT']['version']
__project__ = CONFIG['PROJECT']['name']
__path_api__ = CONFIG['PATH']['api']

flask_app.config['MAIL_SERVER'] = CONFIG['EMAIL']['server']
flask_app.config['MAIL_PORT'] = int(CONFIG['EMAIL']['port'])
flask_app.config['MAIL_USE_TLS'] = CONFIG['EMAIL']['use_tls']
flask_app.config['MAIL_USE_SSL'] = CONFIG['EMAIL']['user_ssl']
flask_app.config['MAIL_USERNAME'] = CONFIG['EMAIL']['username']
flask_app.config['MAIL_DEFAULT_SENDER'] = CONFIG['EMAIL']['username']
flask_app.config['MAIL_PASSWORD'] = CONFIG['EMAIL']['password']
flask_app.config['SECRET_KEY_USERS'] = CONFIG['API']['secret_key']
flask_app.config['DEFAULT_TIME_TOKEN_EXPIRES'] = int(
    CONFIG['API']['default_time_token_expires']
)
flask_app.config['DEFAULT_TIME_TEMPORARY_PASSWORD_EXPIRES'] = int(
    CONFIG['API']['default_time_temporary_password_expires']
)
flask_app.config['DEFAULT_TIME_CSRF_TOKEN_EXPIRES'] = int(
    CONFIG['API']['default_time_csrf_token_expires']
)
flask_app.config['DEFAULT_TIME_NEXT_ATTEMPT_TO_LOGIN'] = int(
    CONFIG['API']['default_time_next_attempt_to_login']
)
flask_app.config['DEFAULT_TIME_CLIENT_TOKEN_EXPIRES'] = int(
    CONFIG['API']['default_time_client_token_expires']
)
debug = CONFIG['PROJECT']['debug']
flask_app.config['UPLOAD_FOLDER'] = os.path.join(flask_app.root_path, "uploads")
flask_app.config['DATABASE_FOLDER'] = os.path.join(flask_app.root_path, "databases")

@flask_app.route('/')
def index():
    return "<b>Bem Vindo!</b>"

CORS(
    flask_app,
    resources={
        r"/api/*":
            {"origins": "*"},
        r"/echo/*":
            {"origins": "*"}
    }
)
from .controllers import *