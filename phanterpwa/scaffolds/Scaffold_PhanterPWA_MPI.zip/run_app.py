import os
import json
from livereload import Server
from core import builder
from core.config import CONFIG

compile_htmls = builder.compile_htmls
compile_styles = builder.compile_styles
compile_script = builder.compile_script
renew_statics = builder.renew_statics
compile_languages = builder.compile_languages
transcrypt_main_file_path = builder.transcrypt_main_file_path
path_app = builder.path_app
python_env = builder.python_env
path_www = builder.path_www
debug = builder.debug
app_server_port = builder.app_server_port
app_server_host = builder.app_server_host

current_folder = os.path.dirname(__file__)

with open("config.json", "w", encoding="utf-8") as f:
    CONFIG['PATH']['project'] = current_folder
    CONFIG['PATH']['api'] = os.path.join(current_folder, "api")
    CONFIG['PATH']['app'] = path_app = os.path.join(current_folder, "app")
    json.dump(CONFIG, f, ensure_ascii=True, indent=2)


def start_server():
    server = Server()
    server.watch(
        os.path.join(path_app, "styles"),
        lambda: compile_styles(),
        ignore=lambda x: False if x[-5:] == ".sass" else True
    )

    server.watcher.ignored_dirs = ["__init__.py", "__pycache__"]
    server.watch(
        os.path.join(path_app, "views"),
        lambda: compile_htmls(
            os.path.join(path_app, "views"), "app.views"),
        ignore=lambda x: True if x[-11:] == "__init__.py" else False
    )
    server.watcher.ignored_dirs = ["__pycache__"]
    server.watch(
        os.path.join(path_app, "languages"),
        lambda: compile_languages(),
        ignore=lambda x: True if x[-11:] == "__init__.py" else False
    )

    server.watcher.ignored_dirs = ["__target__", "production", "debug"]
    server.watch(
        os.path.join(path_app, "scripts"),
        lambda: compile_script(transcrypt_main_file_path, python_env),
        ignore=lambda x: False if ((x[-3:] == ".py") and (x[-11] != "__init__.py")) else True
    )
    server.watch(
        os.path.join(path_app, "statics"),
        renew_statics
    )
    with open(os.path.join(current_folder, "core", "art"), "r", encoding="utf-8") as f:
        print("\n\n", f.read(), "\n\n\n")

    print("App Server running...")
    print('PID process: %s' % os.getpid())
    print("Press CTRL+C to quit")
    print(path_www)
    with open('server_app.pid', 'w') as f:
        f.write(str(os.getpid()))
    try:
        server.serve(port=app_server_port, host=app_server_host, root=path_www)
    except OSError:
        builder.kill_server(True)


start_server()
